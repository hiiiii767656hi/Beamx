# Playit.gg ile internete açık sunucu (Linux gerekmez)

Oyunun içinde sunucu var: **"Sunucu kur ve oyna"** deyince sunucu oyunla birlikte açılır, siz de ilk oyuncu olarak girersiniz.
Aynı Wi-Fi'deki arkadaşlarınız menüde **LAN adresinizi** (oyun içinde sol üstte yazar) yazıp bağlanır.
İnternetten bağlanmaları için port yönlendirme yerine **playit.gg** tüneli kullanılır.

## Tek seferlik kurulum (PC)
1. https://playit.gg adresinde ücretsiz hesap açın, **playit agent** programını indirin
   (Windows: `.exe`, Linux: tek dosya). Dosyayı **oyunun klasörüne** koyun (adı `playit` ile başlamalı; oyun otomatik bulur).
   Linux'ta: `chmod +x playit*`
2. Oyunu açın → **Sunucu kur ve oyna** (menüde `[F3] playit.gg: AÇIK` olmalı).
   Oyun playit'i arka planda başlatır; ilk seferde tarayıcıda **onay (claim) sayfası** açılır → giriş yapıp onaylayın.
   (Açılmazsa ekranın sol üstünde yazan "Playit onayı: https://playit.gg/claim/..." adresini tarayıcıya yazın.)
3. playit.gg panelinde **Tunnels → Add Tunnel → UDP (Custom UDP)** seçin, **Local port = 7777** yapın, ajan olarak bilgisayarınızı seçin.
4. Tünel oluşunca bir adres verir (örn. `xxxx.gl.joinmc.link:12345`).
   Oyun çoğu zaman bunu kendisi yakalayıp sol üstte **"İnternet: ..."** olarak gösterir.
   Yakalayamazsa adresi menüdeki **"Genel adres"** alanına yazın (oyun hatırlar).
5. Arkadaşlarınız menüde **"Katılmak için sunucu"** alanına bu adresi yazıp **Sunucuya bağlan** der.

Sonraki seferlerde: sadece oyunu açıp **Sunucu kur ve oyna**. Tünel adresi hesabınızda sabit kalır.

## Notlar
- Oyun içinde **P** tuşu playit'in çıktısını gösterir (sorun çözmek için).
- Playit'siz de çalışır: `[F3]` ile kapatın; LAN'da ya da kendi port yönlendirmenizle (UDP 7777) oynayın.
- Sunucu oyun penceresiyle birlikte çalışır: sahibi oyunu kapatırsa sunucu da kapanır. Kesintisiz sunucu isterseniz `beamx-server` (ayrı, başsız) hâlâ var.
- Port değiştirmek için "Katılmak için sunucu" alanına `127.0.0.1:7780` gibi yazın (1024 üstü) ve playit tünelinde de aynı portu kullanın.
- **Android:** playit ajanı telefonda çalıştırılamaz. Telefon sunucu kurarsa aynı Wi-Fi / hotspot'taki oyuncular bağlanır;
  internete açmak için sunucuyu PC'de kurun. Telefon ise istemci olarak playit adresine rahatça bağlanır.
- Playit adresi/ajan çıktısı biçimi değişebilir; oyun adresi tanıyamazsa "Genel adres" alanını elle doldurun.
