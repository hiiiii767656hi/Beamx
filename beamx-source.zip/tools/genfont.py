from PIL import Image, ImageDraw, ImageFont
import sys
path="/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
SIZE=15
f=ImageFont.truetype(path,SIZE)
chars=[chr(c) for c in range(32,127)]+list("ğĞşŞıİöÖüÜçÇ")
CW,CH=9,17
out=["// otomatik uretildi: tools/genfont.py (DejaVu Sans Mono Bold, 9x17, 8-bit alpha)",
     "#pragma once","#include <stdint.h>",
     f"static const int FONT_CW={CW}, FONT_CH={CH}, FONT_N={len(chars)};",
     "static const uint32_t FONT_EXTRA[]={"+",".join(str(ord(c)) for c in chars[95:])+"};",
     "static const uint8_t FONT_DATA[]={"]
for c in chars:
    im=Image.new("L",(CW,CH),0); d=ImageDraw.Draw(im)
    d.text((0,0),c,font=f,fill=255)
    out.append(",".join(str(v) for v in im.tobytes())+",")
out.append("};")
open("src/font_data.h","w").write("\n".join(out)+"\n")
# preview
im=Image.new("L",(CW*len(chars),CH),0); d=ImageDraw.Draw(im)
for i,c in enumerate(chars): d.text((i*CW,0),c,font=f,fill=255)
im.save("/tmp/font_preview.png")
print(len(chars),"glyphs")
