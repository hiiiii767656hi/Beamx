// BeamX Android istemcisi: NativeActivity + yazilim rasterizer (ANativeWindow) + dokunmatik kontroller
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <stdio.h>
#include <string>
#include "game.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "BeamX", __VA_ARGS__)

struct Ptr { bool on = false; float x = 0, y = 0; };

struct App {
    android_app* app = nullptr;
    Game* g = nullptr;
    Input in;
    ANativeWindow* win = nullptr;
    bool focus = false;
    int sw = 1, sh = 1, W = 1024, H = 472;
    Ptr ptr[10];
    std::string settingsPath;
};
static App A;

static void loadSettings() { A.g->settingsPath = A.settingsPath; A.g->loadSettings(); }
static void saveSettings() { A.g->saveSettings(); }

static void setupWindow() {
    A.sw = ANativeWindow_getWidth(A.win); A.sh = ANativeWindow_getHeight(A.win);
    if (A.sw < A.sh) std::swap(A.sw, A.sh);          // yatay varsay
    if (A.sw < 1) A.sw = 1;
    if (A.sh < 1) A.sh = 1;
    A.W = 1024; A.H = (int)clampf(1024.0f * A.sh / A.sw, 360, 640);
    ANativeWindow_setBuffersGeometry(A.win, A.W, A.H, WINDOW_FORMAT_RGBA_8888);
    if (!A.g) {
        A.g = new Game(); A.g->touch = true; A.g->init(A.W, A.H); loadSettings();
    } else if (A.g->R.W != A.W || A.g->R.H != A.H) A.g->R.init(A.W, A.H);
}

static void present() {
    ANativeWindow_Buffer b;
    if (!A.win || ANativeWindow_lock(A.win, &b, nullptr) != 0) return;
    const uint32_t* src = A.g->R.px.data();
    int w = std::min(b.width, A.W), h = std::min(b.height, A.H);
    for (int y = 0; y < h; y++) {
        uint32_t* dst = (uint32_t*)b.bits + (size_t)y * b.stride;
        const uint32_t* s = src + (size_t)y * A.W;
        for (int x = 0; x < w; x++) { uint32_t c = s[x]; dst[x] = 0xFF000000u | ((c & 0xFF) << 16) | (c & 0xFF00) | ((c >> 16) & 0xFF); }
    }
    ANativeWindow_unlockAndPost(A.win);
}

static char keyToChar(int code, int meta) {
    bool sh = (meta & AMETA_SHIFT_ON) != 0;
    if (code >= AKEYCODE_A && code <= AKEYCODE_Z) return (char)((sh ? 'A' : 'a') + (code - AKEYCODE_A));
    if (code >= AKEYCODE_0 && code <= AKEYCODE_9) return (char)('0' + (code - AKEYCODE_0));
    if (code >= AKEYCODE_NUMPAD_0 && code <= AKEYCODE_NUMPAD_9) return (char)('0' + (code - AKEYCODE_NUMPAD_0));
    switch (code) {
        case AKEYCODE_PERIOD: case AKEYCODE_NUMPAD_DOT: return '.';
        case AKEYCODE_MINUS: return sh ? '_' : '-';
        case AKEYCODE_SEMICOLON: return sh ? ':' : ';';
        case AKEYCODE_SPACE: return ' ';
        case AKEYCODE_COMMA: return ',';
    }
    return 0;
}

static int32_t onInput(android_app*, AInputEvent* ev) {
    if (!A.g) return 0;
    int type = AInputEvent_getType(ev);
    if (type == AINPUT_EVENT_TYPE_KEY) {
        int code = AKeyEvent_getKeyCode(ev), act = AKeyEvent_getAction(ev);
        if (code == AKEYCODE_BACK) {
            if (act == AKEY_EVENT_ACTION_UP) {
                if (A.g->wantKeyboard) A.g->wantKeyboard = false;
                else if (A.g->mode == Game::MENU) A.g->quitReq = true;
                else A.in.pressed[K_ESC] = true;
            }
            return 1;
        }
        if (act == AKEY_EVENT_ACTION_DOWN) {
            if (code == AKEYCODE_DEL) { A.in.pressed[K_BACK] = true; return 1; }
            if (code == AKEYCODE_ENTER) { A.g->wantKeyboard = false; return 1; }
            char c = keyToChar(code, AKeyEvent_getMetaState(ev));
            if (c) { A.in.text.push_back(c); return 1; }
        }
        return 0;
    }
    if (type == AINPUT_EVENT_TYPE_MOTION) {
        int32_t a = AMotionEvent_getAction(ev);
        int act = a & AMOTION_EVENT_ACTION_MASK;
        int idx = (a & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        int n = (int)AMotionEvent_getPointerCount(ev);
        float sx = (float)A.W / A.sw, sy = (float)A.H / A.sh;
        for (int i = 0; i < n; i++) {
            int id = AMotionEvent_getPointerId(ev, i); if (id < 0 || id >= 10) continue;
            A.ptr[id].x = AMotionEvent_getX(ev, i) * sx; A.ptr[id].y = AMotionEvent_getY(ev, i) * sy;
        }
        if (act == AMOTION_EVENT_ACTION_DOWN || act == AMOTION_EVENT_ACTION_POINTER_DOWN) {
            int id = AMotionEvent_getPointerId(ev, idx);
            if (id >= 0 && id < 10) {
                A.ptr[id].on = true;
                if (A.g->mode != Game::PLAY) A.g->menuTap((int)A.ptr[id].x, (int)A.ptr[id].y, A.in);
            }
        } else if (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_POINTER_UP) {
            int id = AMotionEvent_getPointerId(ev, idx); if (id >= 0 && id < 10) A.ptr[id].on = false;
        } else if (act == AMOTION_EVENT_ACTION_CANCEL) {
            for (auto& p : A.ptr) p.on = false;
        }
        return 1;
    }
    return 0;
}

static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW: A.win = app->window; if (A.win) setupWindow(); break;
        case APP_CMD_TERM_WINDOW: A.win = nullptr; break;
        case APP_CMD_GAINED_FOCUS: A.focus = true; break;
        case APP_CMD_LOST_FOCUS: A.focus = false; for (auto& p : A.ptr) p.on = false; break;
        case APP_CMD_PAUSE: if (A.g) saveSettings(); break;
    }
}

void android_main(android_app* app) {
    A.app = app; app->onAppCmd = onCmd; app->onInputEvent = onInput;
    A.settingsPath = std::string(app->activity->internalDataPath ? app->activity->internalDataPath : "/data/local/tmp") + "/settings.txt";
    netInit();
    double last = nowSec(); int prevMode = 0;
    for (;;) {
        int ev; android_poll_source* src;
        while (ALooper_pollAll((A.win && A.focus) ? 0 : 100, nullptr, &ev, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) { if (A.g) { saveSettings(); A.g->net.close(); } return; }
        }
        if (!A.win || !A.g) continue;
        double now = nowSec(), dt = now - last; last = now;
        // dokunma bolgelerini tus durumuna cevir (oyun sirasinda)
        if (A.g->mode == Game::PLAY) {
            bool down[K_COUNT] = {false};
            for (auto& b : A.g->touchButtons())
                for (auto& p : A.ptr)
                    if (p.on && p.x >= b.x && p.x < b.x + b.w && p.y >= b.y && p.y < b.y + b.h) down[b.key] = true;
            for (int k : {K_A, K_D, K_W, K_S, K_SPACE, K_ESC, K_R, K_C}) A.in.setKey(k, down[k]);
        } else {
            for (int k : {K_A, K_D, K_W, K_S, K_SPACE}) A.in.down[k] = false;
        }
        A.g->update(dt, A.in);
        if (A.g->mode == Game::PLAY) A.g->wantKeyboard = false;
        if (A.g->quitReq) { saveSettings(); A.g->net.close(); ANativeActivity_finish(app->activity); A.g->quitReq = false; }
        if ((int)A.g->mode != prevMode) { if (A.g->mode == Game::CONNECTING) saveSettings(); prevMode = (int)A.g->mode; }
        A.g->render();
        present();
        A.in.beginFrame();      // pressed + text temizle (girdi olaylari bir sonraki kareye birikir)
        double used = nowSec() - now;
        if (used < 1.0 / 60) sleepMs((1.0 / 60 - used) * 1000.0 - 0.5);
    }
}
