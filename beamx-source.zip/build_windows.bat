@echo off
REM MSYS2/MinGW-w64 kuruluysa (g++ PATH'te): Windows'ta dogrudan derleme
if not exist dist-windows mkdir dist-windows
g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -mwindows -o dist-windows\beamx.exe src\main.cpp -lws2_32 -lgdi32 -luser32 -lwinmm -lshell32 || exit /b 1
g++ -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -o dist-windows\beamx-server.exe src\server.cpp -lws2_32 || exit /b 1
echo Hazir: dist-windows\beamx.exe
