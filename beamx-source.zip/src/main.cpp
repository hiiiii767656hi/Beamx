// BeamX istemci (Linux X11 / Windows Win32)
#include <stdlib.h>
#include <string>
#include "game.h"
#include "platform.h"

static void usage() {
    printf("BeamX - yumusak govde arac simulatoru\n"
           "  beamx                          normal baslat (menu)\n"
           "  beamx --connect IP:PORT        dogrudan sunucuya baglan\n"
           "  --name ISIM   --color 0-7   --res 1280x720\n"
           "Gelistirici: --bot IP:PORT SANIYE (penceresiz test botu)  --shot DOSYA.ppm SANIYE [kamera 0-2] [kiris 0/1]\n");
}

int main(int argc, char** argv) {
    int W = 1280, H = 720;
    std::string connect, botAddr, hostBot, shotFile; double botSecs = 20, shotSecs = 4; int shotCam = 0, shotBeams = 0, color = -1;
    std::string nm;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--connect" && i + 1 < argc) connect = argv[++i];
        else if (a == "--name" && i + 1 < argc) nm = argv[++i];
        else if (a == "--color" && i + 1 < argc) color = atoi(argv[++i]) & 7;
        else if (a == "--res" && i + 1 < argc) { if (sscanf(argv[++i], "%dx%d", &W, &H) != 2) { W = 1280; H = 720; } }
        else if (a == "--hostbot" && i + 1 < argc) { hostBot = argv[++i]; if (i + 1 < argc && argv[i + 1][0] != '-') botSecs = atof(argv[++i]); }
        else if (a == "--bot" && i + 1 < argc) { botAddr = argv[++i]; if (i + 1 < argc && argv[i + 1][0] != '-') botSecs = atof(argv[++i]); }
        else if (a == "--shot" && i + 1 < argc) { shotFile = argv[++i]; if (i + 1 < argc && argv[i + 1][0] != '-') shotSecs = atof(argv[++i]);
            if (i + 1 < argc && argv[i + 1][0] != '-') shotCam = atoi(argv[++i]); if (i + 1 < argc && argv[i + 1][0] != '-') shotBeams = atoi(argv[++i]); }
        else { usage(); return a == "--help" ? 0 : 1; }
    }
    W = std::max(640, std::min(2560, W)); H = std::max(360, std::min(1440, H));
    netInit();
    Game g; g.init(W, H);
    {   // ayar dosyasi: ~/.beamx_ayar  (Windows: %USERPROFILE%\\.beamx_ayar)
        const char* h = getenv("HOME"); if (!h) h = getenv("USERPROFILE");
        if (h && botAddr.empty() && hostBot.empty() && shotFile.empty()) { g.settingsPath = std::string(h) + "/.beamx_ayar"; g.loadSettings(); }
    }
    if (!nm.empty()) { strncpy(g.name, nm.c_str(), 15); g.name[15] = 0; }
    if (color >= 0) g.colorIdx = color;

    // ---------- penceresiz SUNUCU SAHIBI (gomulu sunucu testi) ----------
    if (!hostBot.empty()) {
        snprintf(g.addr, sizeof(g.addr), "127.0.0.1:%s", hostBot.c_str());
        g.startHost();
        Input in; double t0 = nowSec(), last = t0, lastPrint = t0;
        while (nowSec() - t0 < botSecs) {
            double now = nowSec(), dt = now - last; last = now;
            in.beginFrame(); in.down[K_W] = true; in.down[K_D] = sin((now - t0) * 0.4) > 0; in.down[K_A] = !in.down[K_D];
            g.update(dt, in);
            if (now - lastPrint > 2.0) {
                lastPrint = now;
                printf("[host] mod=%d sunucu=%d oyuncu=%d lan=%s playit=%d adres='%s' claim='%s'\n", (int)g.mode, g.srv ? 1 : 0, g.srv ? g.srv->count() : -1, g.lanIp.c_str(),
                       g.playit.started ? 1 : 0, g.pubAddr().c_str(), g.claimUrl.c_str());
                fflush(stdout);
            }
            sleepMs(8);
        }
        if (g.srv) for (auto& l : g.srv->logLines) printf("  sunucu> %s\n", l.c_str());
        for (auto& l : g.playitLines) printf("  playit> %s\n", l.c_str());
        g.leave();
        return 0;
    }

    // ---------- penceresiz bot (sunucu/ag testi) ----------
    if (!botAddr.empty()) {
        strncpy(g.addr, botAddr.c_str(), 47);
        g.startConnect();
        Input in; double t0 = nowSec(), last = t0; int maxSeen = 0; double lastPrint = t0;
        while (nowSec() - t0 < botSecs) {
            double now = nowSec(), dt = now - last; last = now;
            in.beginFrame(); double t = now - t0;
            bool right = sin(t * 0.5) > 0;
            in.down[K_W] = true; in.down[K_D] = right; in.down[K_A] = !right;
            g.update(dt, in);
            maxSeen = std::max(maxSeen, g.net.activeCount());
            if (now - lastPrint > 2.0) {
                lastPrint = now;
                printf("[bot %s] mod=%d bagli=%d id=%d ping=%dms uzak=%d hiz=%.0f km/h konum=(%.0f,%.0f) rx=%llu tx=%llu\n", g.name, (int)g.mode, g.net.connected, g.net.myId,
                       g.net.pingMs, g.net.activeCount(), g.car.speed * 3.6f, g.car.center.x, g.car.center.z, (unsigned long long)g.net.rx, (unsigned long long)g.net.tx);
                fflush(stdout);
            }
            sleepMs(8);
        }
        printf("[bot %s] BITTI: gorulen en fazla uzak oyuncu=%d, rx=%llu tx=%llu\n", g.name, maxSeen, (unsigned long long)g.net.rx, (unsigned long long)g.net.tx);
        g.net.close();
        return 0;
    }

    // ---------- ekran goruntusu (penceresiz) ----------
    if (!shotFile.empty()) {
        if (getenv("BX_TOUCH")) g.touch = true;
        if (getenv("BX_KB")) { g.wantKeyboard = true; g.field = 1; }
        if (getenv("BX_MENU")) { Input in0; for (int i = 0; i < 90; i++) g.update(1.0 / 60, in0); g.render(); g.R.savePPM(shotFile.c_str()); return 0; }
        if (getenv("BX_HOST")) { snprintf(g.addr, sizeof(g.addr), "127.0.0.1:7822"); g.startHost(); Input i0; for (int i = 0; i < 150; i++) g.update(1.0 / 60, i0); }
        else g.startSingle();
        g.camMode = shotCam; g.beams = shotBeams != 0; g.help = true;
        Input in; double t = 0; const double dt = 1.0 / 60;
        bool crash = getenv("BX_CRASH") != nullptr;
        if (crash) {
            g.car.build(V3(100, World::height(100, 0) + 0.05f, 0), 0);
            for (int i = 0; i < 60; i++) { g.update(dt, in); }
            for (auto& n : g.car.n) n.v = V3(22, 0, 0);
            for (auto& w : g.car.w) w.omega = 22 / 0.32f;
            g.car.gear = 3; g.car.speed = 22;
        }
        while (t < shotSecs) {
            if (crash) { in.beginFrame(); g.update(dt, in); t += dt; continue; }
            in.beginFrame(); in.down[K_W] = true; in.down[K_D] = (t > 2.5 && t < 3.3);
            g.update(dt, in); t += dt;
        }
        if (getenv("BX_BENCH")) { double b0 = nowSec(); for (int i = 0; i < 100; i++) g.render(); printf("render: %.2f ms/kare\n", (nowSec() - b0) * 10.0); }
        g.render();
        g.R.savePPM(shotFile.c_str());
        printf("kaydedildi: %s (hiz %.0f km/h, vites %d)\n", shotFile.c_str(), g.car.speed * 3.6f, g.car.gear);
        return 0;
    }

    // ---------- normal oyun ----------
    Platform p;
    if (!p.open(W, H, "BeamX")) return 1;
    if (!connect.empty()) { strncpy(g.addr, connect.c_str(), 47); g.addr[47] = 0; g.startConnect(); }
    using clk = std::chrono::steady_clock;
    auto last = clk::now();
    const double target = 1.0 / 60.0;
    while (!p.quit && !g.quitReq) {
        auto now = clk::now();
        double dt = std::chrono::duration<double>(now - last).count(); last = now;
        p.pump();
        g.update(dt, p.in);
        g.render();
        p.present(g.R.px.data());
        double used = std::chrono::duration<double>(clk::now() - now).count();
        if (used < target) sleepMs((target - used) * 1000.0 - 0.7);
    }
    g.saveSettings();
    g.net.close();
    g.stopHost();
    p.close();
    return 0;
}
