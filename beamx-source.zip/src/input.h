#pragma once
#include <string.h>
#include <string>
enum Key { K_W, K_A, K_S, K_D, K_UP, K_DOWN, K_LEFT, K_RIGHT, K_SPACE, K_R, K_C, K_B, K_T, K_H, K_P, K_ESC, K_ENTER, K_TAB, K_F1, K_F2, K_F3, K_BACK, K_SHIFT, K_COUNT };
struct Input {
    bool down[K_COUNT];
    bool pressed[K_COUNT];
    std::string text;
    Input() { memset(down, 0, sizeof(down)); memset(pressed, 0, sizeof(pressed)); }
    void beginFrame() { memset(pressed, 0, sizeof(pressed)); text.clear(); }
    void setKey(int k, bool d) { if (k < 0 || k >= K_COUNT) return; if (d && !down[k]) pressed[k] = true; down[k] = d; }
    void releaseAll() { memset(down, 0, sizeof(down)); }
};
