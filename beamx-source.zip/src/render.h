#pragma once
// Bagimsiz yazilim (CPU) rasterizer: ucgen, z-buffer, sis, alfa, cizgi, metin.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include "font_data.h"
#include "vec.h"

inline uint32_t rgb(int r, int g, int b) { return ((uint32_t)clampf((float)r, 0, 255) << 16) | ((uint32_t)clampf((float)g, 0, 255) << 8) | (uint32_t)clampf((float)b, 0, 255); }
inline uint32_t mixc(uint32_t a, uint32_t b, float t) {
    int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
    return rgb((int)(ar + (br - ar) * t), (int)(ag + (bg - ag) * t), (int)(ab + (bb - ab) * t));
}
inline uint32_t scalec(uint32_t a, float f) { return rgb((int)(((a >> 16) & 255) * f), (int)(((a >> 8) & 255) * f), (int)((a & 255) * f)); }

struct Renderer {
    int W = 0, H = 0;
    std::vector<uint32_t> px;
    std::vector<float> zb;
    V3 cp, cr, cu, cf;
    float focal = 800, cx = 0, cy = 0, znear = 0.15f;
    uint32_t fogCol = rgb(186, 208, 232);
    float fogDensity = 0.0021f;
    V3 sun = norm(V3(0.45f, 0.62f, 0.35f));

    void init(int w, int h) { W = w; H = h; px.assign((size_t)w * h, 0); zb.assign((size_t)w * h, 0); cx = w * 0.5f; cy = h * 0.5f; }

    void setCamera(const V3& pos, const V3& target, const V3& upHint, float fovDeg) {
        cp = pos; cf = norm(target - pos);
        cr = norm(cross(cf, upHint)); cu = cross(cr, cf);
        focal = (W * 0.5f) / tanf(fovDeg * 0.5f * PI_F / 180.0f);
    }
    void setCameraBasis(const V3& pos, const V3& f, const V3& upHint, float fovDeg) { setCamera(pos, pos + f, upHint, fovDeg); }

    V3 toCam(const V3& p) const { V3 d = p - cp; return V3(dot(d, cr), dot(d, cu), dot(d, cf)); }
    bool project(const V3& p, float& sx, float& sy, float& z) const {
        V3 c = toCam(p); if (c.z < znear) return false;
        sx = cx + focal * c.x / c.z; sy = cy - focal * c.y / c.z; z = c.z; return true;
    }

    void clearSky() {
        // ufuk cizgisi
        V3 h = norm(V3(cf.x, 0, cf.z));
        float dz = dot(h, cf);
        float hy = dz > 1e-4f ? cy - focal * dot(h, cu) / dz : (cf.y > 0 ? -1e6f : 1e6f);
        uint32_t top = rgb(58, 108, 196), mid = rgb(120, 168, 224);
        for (int y = 0; y < H; y++) {
            uint32_t c;
            if (y >= hy) c = fogCol;
            else { float t = clampf((hy - y) / std::max(80.0f, hy * 0.9f), 0, 1); c = t < 0.35f ? mixc(fogCol, mid, t / 0.35f) : mixc(mid, top, (t - 0.35f) / 0.65f); }
            uint32_t* row = &px[(size_t)y * W];
            for (int x = 0; x < W; x++) row[x] = c;
        }
        std::fill(zb.begin(), zb.end(), 0.0f);
        // gunes
        V3 sp = cp + sun * 1000.0f; float sx, sy, z;
        if (project(sp, sx, sy, z)) {
            for (int r = 46; r > 0; r -= 2) {
                float a = (r > 20) ? (1.0f - r / 46.0f) * 0.25f : 1.0f;
                blendDisc((int)sx, (int)sy, r, rgb(255, 245, 210), a);
            }
        }
    }

    void blendDisc(int x0, int y0, int r, uint32_t col, float a) {
        for (int y = std::max(0, y0 - r); y <= std::min(H - 1, y0 + r); y++)
            for (int x = std::max(0, x0 - r); x <= std::min(W - 1, x0 + r); x++)
                if ((x - x0) * (x - x0) + (y - y0) * (y - y0) <= r * r) blendPx(x, y, col, a);
    }
    inline void blendPx(int x, int y, uint32_t col, float a) {
        uint32_t& d = px[(size_t)y * W + x];
        if (a >= 0.999f) { d = col; return; }
        int ia = (int)(a * 256);
        uint32_t dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
        uint32_t sr = (col >> 16) & 255, sg = (col >> 8) & 255, sb = col & 255;
        d = ((dr + (((int)sr - (int)dr) * ia >> 8)) << 16) | ((dg + (((int)sg - (int)dg) * ia >> 8)) << 8) | (db + (((int)sb - (int)db) * ia >> 8));
    }

    // ---- 3B ucgen ----
    void tri(const V3& a, const V3& b, const V3& c, uint32_t col, float alpha = 1.0f, bool fog = true, float zbias = 0) {
        V3 v[3] = {toCam(a), toCam(b), toCam(c)};
        V3 poly[4]; int n = 0;
        for (int i = 0; i < 3; i++) {
            const V3& p = v[i]; const V3& q = v[(i + 1) % 3];
            bool pin = p.z >= znear, qin = q.z >= znear;
            if (pin) poly[n++] = p;
            if (pin != qin) { float t = (znear - p.z) / (q.z - p.z); poly[n++] = V3(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, znear); }
        }
        if (n < 3) return;
        if (fog) {
            float zs = 0; for (int i = 0; i < n; i++) zs += poly[i].z; zs /= n;
            float f = 1.0f - expf(-zs * fogDensity);
            if (f > 0.002f) col = mixc(col, fogCol, std::min(f, 0.92f));
        }
        float sx[4], sy[4], iz[4];
        for (int i = 0; i < n; i++) {
            float z = poly[i].z; sx[i] = cx + focal * poly[i].x / z; sy[i] = cy - focal * poly[i].y / z; iz[i] = 1.0f / z + zbias;
        }
        for (int i = 1; i + 1 < n; i++) raster(sx[0], sy[0], iz[0], sx[i], sy[i], iz[i], sx[i + 1], sy[i + 1], iz[i + 1], col, alpha);
    }
    void quad(const V3& a, const V3& b, const V3& c, const V3& d, uint32_t col, float alpha = 1.0f, bool fog = true, float zbias = 0) {
        tri(a, b, c, col, alpha, fog, zbias); tri(a, c, d, col, alpha, fog, zbias);
    }

    void raster(float x0, float y0, float iz0, float x1, float y1, float iz1, float x2, float y2, float iz2, uint32_t col, float alpha) {
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (fabsf(area) < 1e-4f) return;
        if (area < 0) { std::swap(x1, x2); std::swap(y1, y2); std::swap(iz1, iz2); area = -area; }
        int minX = std::max(0, (int)floorf(std::min(x0, std::min(x1, x2))));
        int maxX = std::min(W - 1, (int)ceilf(std::max(x0, std::max(x1, x2))));
        int minY = std::max(0, (int)floorf(std::min(y0, std::min(y1, y2))));
        int maxY = std::min(H - 1, (int)ceilf(std::max(y0, std::max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        // E(a,b,p) = A*px + B*py + C
        float A0 = -(y2 - y1), B0 = (x2 - x1), C0 = (y2 - y1) * x1 - (x2 - x1) * y1;  // w0: edge v1->v2
        float A1 = -(y0 - y2), B1 = (x0 - x2), C1 = (y0 - y2) * x2 - (x0 - x2) * y2;  // w1: edge v2->v0
        float A2 = -(y1 - y0), B2 = (x1 - x0), C2 = (y1 - y0) * x0 - (x1 - x0) * y0;  // w2: edge v0->v1
        float inv = 1.0f / area;
        float izx = (A0 * iz0 + A1 * iz1 + A2 * iz2) * inv;
        bool opaque = alpha >= 0.999f;
        float px0 = minX + 0.5f;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5f;
            float w0 = A0 * px0 + B0 * py + C0, w1 = A1 * px0 + B1 * py + C1, w2 = A2 * px0 + B2 * py + C2;
            int xs = minX, xe = maxX;
            float As[3] = {A0, A1, A2}, ws[3] = {w0, w1, w2};
            for (int e = 0; e < 3; e++) {
                float a = As[e], w = ws[e];
                if (a > 1e-9f) { int d = (int)ceilf(-w / a); if (d > 0) xs = std::max(xs, minX + d); }
                else if (a < -1e-9f) { int d = (int)floorf(w / (-a)); xe = std::min(xe, minX + d); }
                else if (w < 0) { xe = -1; }
            }
            if (xs > xe) continue;
            float dx = (float)(xs - minX);
            float iz = ((w0 + A0 * dx) * iz0 + (w1 + A1 * dx) * iz1 + (w2 + A2 * dx) * iz2) * inv;
            size_t base = (size_t)y * W;
            if (opaque) {
                for (int x = xs; x <= xe; x++, iz += izx) {
                    if (iz > zb[base + x]) { zb[base + x] = iz; px[base + x] = col; }
                }
            } else {
                for (int x = xs; x <= xe; x++, iz += izx)
                    if (iz > zb[base + x]) blendPx(x, y, col, alpha);
            }
        }
    }

    // ---- 3B cizgi (derinlik testsiz) ----
    void line3(const V3& a, const V3& b, uint32_t col) {
        V3 p = toCam(a), q = toCam(b);
        if (p.z < znear && q.z < znear) return;
        if (p.z < znear) { float t = (znear - p.z) / (q.z - p.z); p = V3(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, znear); }
        else if (q.z < znear) { float t = (znear - q.z) / (p.z - q.z); q = V3(q.x + (p.x - q.x) * t, q.y + (p.y - q.y) * t, znear); }
        line2((int)(cx + focal * p.x / p.z), (int)(cy - focal * p.y / p.z), (int)(cx + focal * q.x / q.z), (int)(cy - focal * q.y / q.z), col);
    }

    // ---- 2B ----
    void line2(int x0, int y0, int x1, int y1, uint32_t col, float alpha = 1.0f) {
        if (std::abs(x0) > 20000 || std::abs(y0) > 20000 || std::abs(x1) > 20000 || std::abs(y1) > 20000) return;
        int dx = std::abs(x1 - x0), dy = -std::abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
        for (;;) {
            if (x0 >= 0 && x0 < W && y0 >= 0 && y0 < H) blendPx(x0, y0, col, alpha);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }
    void rect(int x, int y, int w, int h, uint32_t col, float alpha = 1.0f) {
        for (int yy = std::max(0, y); yy < std::min(H, y + h); yy++)
            for (int xx = std::max(0, x); xx < std::min(W, x + w); xx++) blendPx(xx, yy, col, alpha);
    }
    void frame(int x, int y, int w, int h, uint32_t col, float alpha = 1.0f) {
        line2(x, y, x + w, y, col, alpha); line2(x + w, y, x + w, y + h, col, alpha); line2(x + w, y + h, x, y + h, col, alpha); line2(x, y + h, x, y, col, alpha);
    }
    void arc(int cxp, int cyp, float r, float a0, float a1, uint32_t col, float alpha = 1.0f, int thick = 1) {
        int steps = std::max(8, (int)(fabsf(a1 - a0) * r / 3));
        float px_ = cxp + cosf(a0) * r, py_ = cyp + sinf(a0) * r;
        for (int i = 1; i <= steps; i++) {
            float a = a0 + (a1 - a0) * i / steps;
            float nx = cxp + cosf(a) * r, ny = cyp + sinf(a) * r;
            for (int t = 0; t < thick; t++) line2((int)px_, (int)py_ + t, (int)nx, (int)ny + t, col, alpha);
            px_ = nx; py_ = ny;
        }
    }

    // ---- metin (UTF-8, Turkce karakterler dahil) ----
    static int glyphIndex(uint32_t cp) {
        if (cp >= 32 && cp <= 126) return (int)cp - 32;
        for (int i = 0; i < FONT_N - 95; i++) if (FONT_EXTRA[i] == cp) return 95 + i;
        return '?' - 32;
    }
    static int textWidth(const char* s, int scale = 1) {
        int n = 0;
        for (const unsigned char* p = (const unsigned char*)s; *p; p++) if ((*p & 0xC0) != 0x80) n++;
        return n * FONT_CW * scale;
    }
    void text(int x, int y, const char* s, uint32_t col, int scale = 1, float alpha = 1.0f, bool shadow = true) {
        if (shadow) { textRaw(x + scale, y + scale, s, rgb(0, 0, 0), scale, alpha * 0.7f); }
        textRaw(x, y, s, col, scale, alpha);
    }
    void textCentered(int xc, int y, const char* s, uint32_t col, int scale = 1, float alpha = 1.0f) { text(xc - textWidth(s, scale) / 2, y, s, col, scale, alpha); }
    void textRaw(int x, int y, const char* s, uint32_t col, int scale, float alpha) {
        const unsigned char* p = (const unsigned char*)s;
        while (*p) {
            uint32_t cp = *p++;
            if (cp >= 0xC0 && cp < 0xE0 && *p) { cp = ((cp & 0x1F) << 6) | (*p++ & 0x3F); }
            else if (cp >= 0xE0 && *p && p[1]) { cp = ((cp & 0x0F) << 12) | ((p[0] & 0x3F) << 6) | (p[1] & 0x3F); p += 2; }
            const uint8_t* g = &FONT_DATA[(size_t)glyphIndex(cp) * FONT_CW * FONT_CH];
            for (int gy = 0; gy < FONT_CH; gy++)
                for (int gx = 0; gx < FONT_CW; gx++) {
                    uint8_t a8 = g[gy * FONT_CW + gx];
                    if (a8 < 8) continue;
                    float a = a8 / 255.0f * alpha;
                    for (int sy = 0; sy < scale; sy++)
                        for (int sx = 0; sx < scale; sx++) {
                            int xx = x + gx * scale + sx, yy = y + gy * scale + sy;
                            if (xx >= 0 && xx < W && yy >= 0 && yy < H) blendPx(xx, yy, col, a);
                        }
                }
            x += FONT_CW * scale;
        }
    }

    bool savePPM(const char* path) const {
        FILE* f = fopen(path, "wb"); if (!f) return false;
        fprintf(f, "P6\n%d %d\n255\n", W, H);
        for (size_t i = 0; i < px.size(); i++) { unsigned char c[3] = {(unsigned char)(px[i] >> 16), (unsigned char)(px[i] >> 8), (unsigned char)px[i]}; fwrite(c, 1, 3, f); }
        fclose(f); return true;
    }
};
