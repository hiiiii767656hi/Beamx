#pragma once
// Pencere + girdi + ekrana basma: Linux (X11) ve Windows (Win32)
#include <stdint.h>
#include <stdio.h>
#include <string>
#include "input.h"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <mmsystem.h>

struct Platform {
    HWND hwnd = nullptr; HDC hdc = nullptr; BITMAPINFO bmi; int w = 0, h = 0;
    bool quit = false;
    Input in;
    static Platform*& self() { static Platform* p = nullptr; return p; }

    static int mapVK(WPARAM vk) {
        if (vk >= 'A' && vk <= 'Z') {
            switch (vk) { case 'W': return K_W; case 'A': return K_A; case 'S': return K_S; case 'D': return K_D; case 'R': return K_R; case 'C': return K_C;
                          case 'B': return K_B; case 'T': return K_T; case 'H': return K_H; case 'P': return K_P; default: return -1; }
        }
        switch (vk) {
            case VK_UP: return K_UP; case VK_DOWN: return K_DOWN; case VK_LEFT: return K_LEFT; case VK_RIGHT: return K_RIGHT;
            case VK_SPACE: return K_SPACE; case VK_ESCAPE: return K_ESC; case VK_RETURN: return K_ENTER; case VK_TAB: return K_TAB;
            case VK_F1: return K_F1; case VK_F2: return K_F2; case VK_F3: return K_F3; case VK_BACK: return K_BACK; case VK_SHIFT: return K_SHIFT;
        }
        return -1;
    }
    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        Platform* p = self();
        if (p) {
            switch (msg) {
                case WM_CLOSE: p->quit = true; return 0;
                case WM_DESTROY: p->quit = true; return 0;
                case WM_KEYDOWN: case WM_SYSKEYDOWN: { int k = mapVK(wp); if (k >= 0) p->in.setKey(k, true); if (msg == WM_SYSKEYDOWN && wp == VK_F4) p->quit = true; return 0; }
                case WM_KEYUP: case WM_SYSKEYUP: { int k = mapVK(wp); if (k >= 0) p->in.setKey(k, false); return 0; }
                case WM_CHAR: if (wp >= 32 && wp <= 126) p->in.text.push_back((char)wp); return 0;
                case WM_KILLFOCUS: p->in.releaseAll(); return 0;
                case WM_ERASEBKGND: return 1;
            }
        }
        return DefWindowProcA(hwnd, msg, wp, lp);
    }
    bool open(int width, int height, const char* title) {
        w = width; h = height; self() = this;
        timeBeginPeriod(1);
        HINSTANCE hi = GetModuleHandleA(nullptr);
        WNDCLASSA wc; memset(&wc, 0, sizeof(wc));
        wc.lpfnWndProc = WndProc; wc.hInstance = hi; wc.lpszClassName = "BeamXWindow"; wc.hCursor = LoadCursorA(nullptr, (LPCSTR)IDC_ARROW);
        if (!RegisterClassA(&wc)) return false;
        DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
        RECT r = {0, 0, w, h}; AdjustWindowRect(&r, style, FALSE);
        hwnd = CreateWindowExA(0, "BeamXWindow", title, style, CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, nullptr, nullptr, hi, nullptr);
        if (!hwnd) return false;
        ShowWindow(hwnd, SW_SHOW); hdc = GetDC(hwnd);
        memset(&bmi, 0, sizeof(bmi));
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bmi.bmiHeader.biWidth = w; bmi.bmiHeader.biHeight = -h;
        bmi.bmiHeader.biPlanes = 1; bmi.bmiHeader.biBitCount = 32; bmi.bmiHeader.biCompression = BI_RGB;
        return true;
    }
    void pump() {
        in.beginFrame();
        MSG msg;
        while (PeekMessageA(&msg, nullptr, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) quit = true;
            TranslateMessage(&msg); DispatchMessageA(&msg);
        }
    }
    void present(const uint32_t* px) { StretchDIBits(hdc, 0, 0, w, h, 0, 0, w, h, px, &bmi, DIB_RGB_COLORS, SRCCOPY); }
    void setTitle(const char* t) { SetWindowTextA(hwnd, t); }
    void close() { if (hwnd) { ReleaseDC(hwnd, hdc); DestroyWindow(hwnd); hwnd = nullptr; } }
};

#else  // ---------------- Linux / X11 ----------------
#include <X11/XKBlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

struct Platform {
    Display* dpy = nullptr; Window win = 0; GC gc = nullptr; XImage* img = nullptr; Atom wmDelete = 0;
    int w = 0, h = 0;
    bool quit = false;
    Input in;

    static int mapKey(KeySym ks) {
        switch (ks) {
            case XK_w: case XK_W: return K_W; case XK_a: case XK_A: return K_A; case XK_s: case XK_S: return K_S; case XK_d: case XK_D: return K_D;
            case XK_r: case XK_R: return K_R; case XK_c: case XK_C: return K_C; case XK_b: case XK_B: return K_B; case XK_t: case XK_T: return K_T;
            case XK_h: case XK_H: return K_H; case XK_p: case XK_P: return K_P;
            case XK_Up: return K_UP; case XK_Down: return K_DOWN; case XK_Left: return K_LEFT; case XK_Right: return K_RIGHT;
            case XK_space: return K_SPACE; case XK_Escape: return K_ESC; case XK_Return: case XK_KP_Enter: return K_ENTER; case XK_Tab: return K_TAB;
            case XK_F1: return K_F1; case XK_F2: return K_F2; case XK_F3: return K_F3; case XK_BackSpace: return K_BACK;
            case XK_Shift_L: case XK_Shift_R: return K_SHIFT;
        }
        return -1;
    }
    bool open(int width, int height, const char* title) {
        w = width; h = height;
        dpy = XOpenDisplay(nullptr);
        if (!dpy) { fprintf(stderr, "X11 ekranina baglanilamadi (DISPLAY ayarli mi?)\n"); return false; }
        int scr = DefaultScreen(dpy);
        win = XCreateSimpleWindow(dpy, RootWindow(dpy, scr), 0, 0, w, h, 0, 0, BlackPixel(dpy, scr));
        XStoreName(dpy, win, title);
        XSizeHints* sh = XAllocSizeHints(); sh->flags = PMinSize | PMaxSize; sh->min_width = sh->max_width = w; sh->min_height = sh->max_height = h;
        XSetWMNormalHints(dpy, win, sh); XFree(sh);
        XSelectInput(dpy, win, KeyPressMask | KeyReleaseMask | StructureNotifyMask | ExposureMask | FocusChangeMask);
        wmDelete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
        XSetWMProtocols(dpy, win, &wmDelete, 1);
        XkbSetDetectableAutoRepeat(dpy, True, nullptr);
        gc = XCreateGC(dpy, win, 0, nullptr);
        XMapWindow(dpy, win);
        XFlush(dpy);
        return true;
    }
    void makeImage(uint32_t* px) {
        if (img) return;
        int scr = DefaultScreen(dpy);
        img = XCreateImage(dpy, DefaultVisual(dpy, scr), DefaultDepth(dpy, scr), ZPixmap, 0, (char*)px, w, h, 32, 0);
    }
    void pump() {
        in.beginFrame();
        while (XPending(dpy)) {
            XEvent ev; XNextEvent(dpy, &ev);
            switch (ev.type) {
                case ClientMessage: if ((Atom)ev.xclient.data.l[0] == wmDelete) quit = true; break;
                case DestroyNotify: quit = true; break;
                case FocusOut: in.releaseAll(); break;
                case KeyPress: {
                    char buf[16]; KeySym ks = 0;
                    int n = XLookupString(&ev.xkey, buf, sizeof(buf), &ks, nullptr);
                    for (int i = 0; i < n; i++) if (buf[i] >= 32 && buf[i] <= 126) in.text.push_back(buf[i]);
                    int k = mapKey(XLookupKeysym(&ev.xkey, 0)); if (k < 0) k = mapKey(ks);
                    if (k >= 0) in.setKey(k, true);
                    break;
                }
                case KeyRelease: {
                    int k = mapKey(XLookupKeysym(&ev.xkey, 0));
                    if (k >= 0) in.setKey(k, false);
                    break;
                }
            }
        }
    }
    void present(const uint32_t* px) {
        makeImage(const_cast<uint32_t*>(px));
        XPutImage(dpy, win, gc, img, 0, 0, 0, 0, w, h);
        XFlush(dpy);
    }
    void setTitle(const char* t) { XStoreName(dpy, win, t); }
    void close() {
        if (img) { img->data = nullptr; XDestroyImage(img); img = nullptr; }
        if (dpy) { if (gc) XFreeGC(dpy, gc); XDestroyWindow(dpy, win); XCloseDisplay(dpy); dpy = nullptr; }
    }
};
#endif
