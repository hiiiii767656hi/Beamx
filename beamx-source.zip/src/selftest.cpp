// Fizik motoru testi (grafik/ag yok)
#include <cstdio>
#include <chrono>
#include "car.h"

static World W;
static void nearBoxes(const Car& c, std::vector<int>& out) {
    out.clear();
    for (size_t i = 0; i < W.boxes.size(); i++) {
        const Box& b = W.boxes[i];
        float r = fmaxf(b.h.x, b.h.z) * 1.5f + 14;
        if (fabsf(b.c.x - c.center.x) < r && fabsf(b.c.z - c.center.z) < r) out.push_back((int)i);
    }
}
static void run(Car& c, float secs, float thr, float brk, float steer, float hand = 0) {
    std::vector<int> nb;
    int frames = (int)(secs * 60);
    for (int f = 0; f < frames; f++) {
        c.inThrottle = thr; c.inBrake = brk; c.steerIn = steer; c.inHand = hand;
        c.updateControls(1.0f / 60);
        nearBoxes(c, nb);
        for (int s = 0; s < 16; s++) c.step(cfg::DT, &nb, W, nullptr);
    }
}
static void setVel(Car& c, V3 v) { for (auto& n : c.n) n.v = v; for (auto& w : c.w) w.omega = len(v) / cfg::WHEEL_R; c.speed = len(v); float s = len(v); c.gear = s > 35 ? 5 : s > 25 ? 4 : s > 16 ? 3 : s > 9 ? 2 : 1; c.rpm = 3000; }

int main() {
    W.build();
    printf("== BeamX fizik testi ==\n");
    {
        Car c; c.build(V3(0, 0, 0), 0);
        printf("kutle: %.0f kg, dugum: %zu, kiris: %zu, ornek: %zu\n", c.totalMass, c.n.size(), c.b.size(), c.samples.size());
        run(c, 3.0f, 0, 0, 0);
        printf("[oturma] merkez y=%.3f  hub y: %.3f %.3f %.3f %.3f  Fn: %.0f %.0f %.0f %.0f  hiz=%.4f\n", c.center.y, c.n[24].p.y, c.n[25].p.y,
               c.n[26].p.y, c.n[27].p.y, c.w[0].Fn, c.w[1].Fn, c.w[2].Fn, c.w[3].Fn, len(c.vel));
        printf("         alt dugum y: %.3f  hasar=%.2f%%  saglikli=%d\n", c.n[ix(3, 0)].p.y, c.damage(), c.healthy());
    }
    {
        Car c; c.build(V3(-200, 0, -100), 0);
        run(c, 1.0f, 0, 0, 0);
        auto t0 = std::chrono::steady_clock::now();
        float t100 = -1, t160 = -1, t = 0; int lastG = 1; int frames = 0;
        for (int f = 0; f < 60 * 30; f++) {
            run(c, 1.0f / 60, 1, 0, 0); t += 1.0f / 60; frames++;
            if (t100 < 0 && c.speed > 27.78f) t100 = t;
            if (t160 < 0 && c.speed > 44.4f) t160 = t;
            if (c.gear != lastG) { printf("   t=%.1f vites %d->%d hiz=%.0f km/h rpm=%.0f\n", t, lastG, c.gear, c.speed * 3.6f, c.rpm); lastG = c.gear; }
            if (c.center.x > 190) break;
        }
        auto dtm = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        printf("[hizlanma] 0-160: %.2f s  0-100 km/h: %.2f s, 30 sn sonra hiz: %.0f km/h, rpm=%.0f, x=%.0f  (cpu: %.2f ms/kare)\n", t160, t100, c.speed * 3.6f, c.rpm, c.center.x, dtm * 1000 / frames);
        // fren
        float x0 = c.center.x; float s0 = c.speed;
        run(c, 0.0f, 0, 1, 0);
        float tb = 0;
        while (c.speed > 0.3f && tb < 15) { run(c, 1.0f / 60, 0, 1, 0); tb += 1.0f / 60; }
        printf("[fren] %.0f km/h -> 0: %.1f m, %.2f s\n", s0 * 3.6f, c.center.x - x0, tb);
    }
    {
        Car c; c.build(V3(-200, 0, -100), 0);
        run(c, 1.0f, 0, 0, 0);
        setVel(c, V3(14, 0, 0));
        run(c, 0.3f, 0.3f, 0, 0);
        float yaw0 = atan2f(c.fwd.z, c.fwd.x);
        run(c, 3.0f, 0.2f, 0, 0.5f);
        float yaw1 = atan2f(c.fwd.z, c.fwd.x);
        float v = len(c.vel);
        printf("[viraj] v=%.1f m/s, donus hizi=%.1f deg/s, lat g~%.2f\n", v, (yaw1 - yaw0) * 57.3f / 3.0f, v * (yaw1 - yaw0) / 3.0f / 9.81f);
    }
    {
        Car c; c.build(V3(105, 0, 0), 0);
        run(c, 1.0f, 0, 0, 0);
        printf("[carpisma] duvar x=135, arac on ucu: %.2f\n", c.n[ix(5, 0)].p.x + 0);
        float v0 = 60 / 3.6f;
        setVel(c, V3(v0, 0, 0));
        float minX = 1e9, maxX = -1e9;
        for (int f = 0; f < 60 * 4; f++) {
            run(c, 1.0f / 60, 0, 0.0f, 0);
            for (int i = 0; i < 24; i++) { maxX = fmaxf(maxX, c.n[i].p.x); }
        }
        printf("   60 km/h duvara: en uc x=%.2f (duvar yuzu 134.2) hasar=%.1f%% kopan kiris=%d saglikli=%d son hiz=%.2f\n", maxX, c.damage(), c.brokenCount, c.healthy(), len(c.vel));
        printf("   on tampon->kabin mesafe: s5-s2 = %.2f (orijinal 2.45)\n", c.n[ix(5, 0)].p.x - c.n[ix(2, 0)].p.x);
    }
    {
        Car c; c.build(V3(105, 0, 0), 0);
        run(c, 1.0f, 0, 0, 0);
        setVel(c, V3(120 / 3.6f, 0, 0));
        float maxX = -1e9;
        for (int f = 0; f < 60 * 4; f++) { run(c, 1.0f / 60, 0, 0, 0); for (int i = 0; i < 24; i++) maxX = fmaxf(maxX, c.n[i].p.x); }
        printf("[carpisma 120km/h] en uc x=%.2f hasar=%.1f%% kopan=%d saglikli=%d\n", maxX, c.damage(), c.brokenCount, c.healthy());
    }
    {
        Car c; c.build(V3(20, 0, 0), 0);
        run(c, 1.0f, 0, 0, 0);
        float maxY = 0, landX = 0; bool air = false;
        setVel(c, V3(25, 0, 0));
        for (int f = 0; f < 60 * 8; f++) {
            run(c, 1.0f / 60, 0.6f, 0, 0);
            maxY = fmaxf(maxY, c.center.y);
            if (c.w[0].contact == false && c.w[1].contact == false && c.w[2].contact == false && c.w[3].contact == false) air = true;
        }
        printf("[rampa] 90 km/h: en yuksek y=%.2f havada=%d, son x=%.1f hasar=%.1f%% saglikli=%d\n", maxY, air, c.center.x, c.damage(), c.healthy());
    }
    {   // takla / devrilme
        Car c; c.build(V3(-200, 0, -100), 0);
        run(c, 1.0f, 0, 0, 0);
        setVel(c, V3(25, 0, 0));
        run(c, 0.3f, 0.0f, 0, 0);
        run(c, 2.0f, 0, 0, 1.0f);
        printf("[sert viraj 90km/h] up.y=%.2f hasar=%.1f%% saglikli=%d\n", c.up.y, c.damage(), c.healthy());
    }
    return 0;
}
