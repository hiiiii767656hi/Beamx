#pragma once
// BeamX arac simulasyonu: dugum-kiris (node-beam) yumusak govde fizigi.
#include <algorithm>
#include <utility>
#include <vector>
#include "proto.h"
#include "vec.h"
#include "world.h"

struct Node { V3 p, v, f; float m; };
struct Beam {
    int a, b;
    float k, c, rest, rest0, yield, brk, minL, maxL;
    uint8_t type;  // 0 normal(plastik), 1 suspansiyon (sinirli)
    bool broken, surface;
};
struct Wheel {
    int hub;
    bool front, drive;
    float omega = 0, angle = 0, Fn = 0, slip = 0;
    bool contact = false, detached = false;
    int arm0 = -1, arm1 = -1;
};
struct RPoint { V3 p, v; };

namespace cfg {
static const float DT = 0.001f;           // sabit fizik adimi (1000 Hz)
static const float WHEEL_R = 0.32f;
static const float WHEEL_I = 1.5f;
static const float FINAL = 3.9f;
static const float IDLE = 900.0f;
static const float REDLINE = 6800.0f;
static const float GEARS[7] = {0, 3.5f, 2.1f, 1.45f, 1.1f, 0.88f, 0.72f};
static const float REVERSE = -3.4f;
}  // namespace cfg

inline float engineTorque(float rpm) {
    static const float R[] = {0, 900, 1500, 2500, 3500, 4500, 5500, 6500, 7000, 8000};
    static const float T[] = {90, 170, 230, 300, 345, 365, 355, 310, 230, 110};
    if (rpm <= R[0]) return T[0];
    for (int i = 1; i < 10; i++)
        if (rpm <= R[i]) return lerpf(T[i - 1], T[i], (rpm - R[i - 1]) / (R[i] - R[i - 1]));
    return T[9];
}

inline int ix(int s, int c) { return s * 4 + c; }  // c: 0=sol alt,1=sag alt,2=sol ust,3=sag ust

// Penalti tabanli kutu carpismasi
inline bool collideBox(const Box& bx, const V3& p, float r, V3& nrm, float& pen) {
    V3 l = bx.toLocal(p);
    float dx = bx.h.x + r - fabsf(l.x), dy = bx.h.y + r - fabsf(l.y), dz = bx.h.z + r - fabsf(l.z);
    if (dx <= 0 || dy <= 0 || dz <= 0) return false;
    V3 ln;
    if (dx <= dy && dx <= dz) { ln = V3(l.x > 0 ? 1.f : -1.f, 0, 0); pen = dx; }
    else if (dy <= dz) { ln = V3(0, l.y > 0 ? 1.f : -1.f, 0); pen = dy; }
    else { ln = V3(0, 0, l.z > 0 ? 1.f : -1.f); pen = dz; }
    nrm = bx.toWorldDir(ln);
    return true;
}

struct Car {
    std::vector<Node> n;
    std::vector<Beam> b;
    Wheel w[4];  // 0=SolOn 1=SagOn 2=SolArka 3=SagArka
    std::vector<std::pair<int, int>> samples;  // carpisma ornekleri (dugum veya kiris orta noktasi)
    // girdiler
    float inThrottle = 0, inBrake = 0, inHand = 0, steerIn = 0;
    // etkin degerler
    float throttle = 0, brake = 0, steerAngle = 0;
    int gear = 1;
    float rpm = cfg::IDLE, shiftT = 0, shiftCool = 0;
    // cerceve
    V3 fwd = V3(1, 0, 0), right = V3(0, 0, 1), up = V3(0, 1, 0), center, vel;
    float speed = 0;  // ileri hiz (m/s)
    float totalMass = 0;
    uint32_t respawnCount = 0;
    float maxStrainSeen = 0;
    int brokenCount = 0;
    bool tcsOn = true;
    float tcsF = 1.0f;

    static const int NCH = 24, NN = 28;

    void build(V3 pos, float yaw) {
        n.clear(); b.clear(); samples.clear();
        brokenCount = 0;
        struct St { float x, bY, tY, wb, wt, mf; };
        static const St S[6] = {{-2.0f, 0.40f, 0.90f, 0.70f, 0.65f, 0.85f}, {-1.3f, 0.38f, 0.95f, 0.75f, 0.70f, 0.90f},
                                {-0.45f, 0.38f, 1.40f, 0.75f, 0.62f, 1.00f}, {0.45f, 0.38f, 1.40f, 0.75f, 0.62f, 1.00f},
                                {1.3f, 0.38f, 0.98f, 0.75f, 0.68f, 1.20f}, {2.0f, 0.38f, 0.85f, 0.70f, 0.62f, 1.25f}};
        float cs = cosf(yaw), sn = sinf(yaw);
        auto W = [&](float lx, float ly, float lz) { return V3(pos.x + lx * cs - lz * sn, pos.y + ly, pos.z + lx * sn + lz * cs); };
        for (int s = 0; s < 6; s++)
            for (int c = 0; c < 4; c++) {
                float y = c < 2 ? S[s].bY : S[s].tY, hw = c < 2 ? S[s].wb : S[s].wt;
                float z = (c % 2 == 0) ? -hw : hw;
                Node nd; nd.p = W(S[s].x, y, z); nd.v = V3(); nd.f = V3();
                nd.m = 42.0f * S[s].mf * (c < 2 ? 1.25f : 0.75f);
                n.push_back(nd);
            }
        const float HX[4] = {1.3f, 1.3f, -1.3f, -1.3f};
        const float HZ[4] = {-1.0f, 1.0f, -1.0f, 1.0f};
        for (int i = 0; i < 4; i++) {
            Node nd; nd.p = W(HX[i], cfg::WHEEL_R, HZ[i]); nd.m = 25.0f; n.push_back(nd);
        }
        totalMass = 0; for (auto& nd : n) totalMass += nd.m;

        auto addB = [&](int a, int c, float k, float damp, float yield, float brk, bool surf, uint8_t type = 0) {
            Beam bm; bm.a = a; bm.b = c; bm.k = k; bm.c = damp; bm.rest = bm.rest0 = len(n[c].p - n[a].p);
            bm.yield = yield; bm.brk = brk; bm.type = type; bm.broken = false; bm.surface = surf;
            bm.minL = bm.maxL = bm.rest;
            b.push_back(bm); return (int)b.size() - 1;
        };
        // bolgeye gore akma siniri (on/arka ezilme bolgesi yumusak, kabin sert)
        const float PY[5] = {0.045f, 0.065f, 0.11f, 0.08f, 0.045f};
        const float K = 3.5e5f, KD = 3.0e5f, C = 500.0f;
        for (int s = 0; s < 6; s++) {
            float y = PY[std::min(s, 4)];
            if (s > 0) y = std::min(y, PY[s - 1]);
            addB(ix(s, 0), ix(s, 1), K, C, y, 0.6f, true);
            addB(ix(s, 2), ix(s, 3), K, C, y, 0.6f, true);
            addB(ix(s, 0), ix(s, 2), K, C, y, 0.6f, true);
            addB(ix(s, 1), ix(s, 3), K, C, y, 0.6f, true);
            addB(ix(s, 0), ix(s, 3), KD, C, y, 0.6f, false);
            addB(ix(s, 1), ix(s, 2), KD, C, y, 0.6f, false);
        }
        for (int s = 0; s < 5; s++) {
            float y = PY[s];
            for (int c = 0; c < 4; c++) addB(ix(s, c), ix(s + 1, c), K, C, y, 0.6f, true);
            // yuz capraz
            addB(ix(s, 0), ix(s + 1, 1), KD, C, y, 0.6f, true); addB(ix(s, 1), ix(s + 1, 0), KD, C, y, 0.6f, true);
            addB(ix(s, 2), ix(s + 1, 3), KD, C, y, 0.6f, true); addB(ix(s, 3), ix(s + 1, 2), KD, C, y, 0.6f, true);
            addB(ix(s, 0), ix(s + 1, 2), KD, C, y, 0.6f, true); addB(ix(s, 2), ix(s + 1, 0), KD, C, y, 0.6f, true);
            addB(ix(s, 1), ix(s + 1, 3), KD, C, y, 0.6f, true); addB(ix(s, 3), ix(s + 1, 1), KD, C, y, 0.6f, true);
            // govde capraz
            addB(ix(s, 0), ix(s + 1, 3), KD, C, y, 0.6f, false); addB(ix(s, 1), ix(s + 1, 2), KD, C, y, 0.6f, false);
            addB(ix(s, 2), ix(s + 1, 1), KD, C, y, 0.6f, false); addB(ix(s, 3), ix(s + 1, 0), KD, C, y, 0.6f, false);
        }
        for (int s = 0; s < 4; s++)
            for (int c = 0; c < 4; c++) addB(ix(s, c), ix(s + 2, c), 2.5e5f, C, PY[s] * 1.1f, 0.6f, true);
        // suspansiyon: salinim kollari + amortisor
        const int ARM[4][2] = {{ix(3, 0), ix(5, 0)}, {ix(3, 1), ix(5, 1)}, {ix(0, 0), ix(2, 0)}, {ix(0, 1), ix(2, 1)}};
        const int STRUT[4] = {ix(4, 2), ix(4, 3), ix(1, 2), ix(1, 3)};
        for (int i = 0; i < 4; i++) {
            int hub = 24 + i;
            w[i] = Wheel(); w[i].hub = hub; w[i].front = i < 2; w[i].drive = i >= 2;
            w[i].arm0 = addB(hub, ARM[i][0], 4.0e5f, 800.0f, 0.02f, 0.12f, false);
            w[i].arm1 = addB(hub, ARM[i][1], 4.0e5f, 800.0f, 0.02f, 0.12f, false);
            int sb = addB(hub, STRUT[i], 45000.0f, 2800.0f, 10.0f, 0.5f, false, 1);
            Beam& sbm = b[sb];
            float L0 = sbm.rest0;
            sbm.rest = L0 + 0.09f; sbm.minL = L0 - 0.11f; sbm.maxL = L0 + 0.14f;
        }
        // carpisma ornekleri
        for (int i = 0; i < NCH; i++) samples.push_back({i, -1});
        for (size_t i = 0; i < b.size(); i++) if (b[i].surface) samples.push_back({b[i].a, b[i].b});
        gear = 1; rpm = cfg::IDLE; shiftT = shiftCool = 0; speed = 0;
        throttle = brake = steerAngle = 0;
        computeFrame();
    }

    void computeFrame() {
        V3 fr, rr, R, L, cen, vv;
        for (int c = 0; c < 4; c++) { fr += n[ix(4, c)].p + n[ix(5, c)].p; rr += n[ix(0, c)].p + n[ix(1, c)].p; }
        fwd = norm(fr * 0.125f - rr * 0.125f);
        for (int s = 0; s < 6; s++) { R += n[ix(s, 1)].p + n[ix(s, 3)].p; L += n[ix(s, 0)].p + n[ix(s, 2)].p; }
        V3 rv = R * (1.0f / 12) - L * (1.0f / 12);
        up = norm(cross(rv, fwd));
        right = norm(cross(fwd, up));
        fwd = norm(cross(up, right));
        for (int i = 0; i < NCH; i++) { cen += n[i].p; vv += n[i].v; }
        center = cen * (1.0f / NCH); vel = vv * (1.0f / NCH);
        speed = dot(vel, fwd);
    }

    // kare basina bir kez: surucu girdilerini etkin degerlere cevir, vites mantigi
    void updateControls(float frameDt) {
        float spd = speed;
        if (gear >= 1) {
            if (inBrake > 0.1f && inThrottle < 0.1f && spd < 0.8f) { gear = -1; shiftT = 0.2f; }
        } else if (gear == -1) {
            if (inThrottle > 0.1f && inBrake < 0.1f && spd > -0.8f) { gear = 1; shiftT = 0.2f; }
        } else gear = 1;
        if (gear == -1) { throttle = inBrake; brake = inThrottle; }
        else { throttle = inThrottle; brake = inBrake; }
        // direksiyon: hiza bagli maksimum aci
        float s = fabsf(spd);
        float maxS = 0.62f / (1.0f + powf(s / 14.0f, 1.5f));
        steerAngle = steerIn * maxS;
        // otomatik vites
        shiftCool -= frameDt;
        if (gear >= 1 && shiftCool <= 0) {
            // karar, patinajdan etkilenmesin diye gercek arac hizindan turetilen devre gore verilir
            float sRpm = fabsf(spd) / cfg::WHEEL_R * 9.5493f * cfg::GEARS[gear] * cfg::FINAL;
            float upRpm = throttle > 0.2f ? 6300.0f : 4300.0f;
            float rUp = gear < 6 ? sRpm * cfg::GEARS[gear + 1] / cfg::GEARS[gear] : 0;
            float rDn = gear > 1 ? sRpm * cfg::GEARS[gear - 1] / cfg::GEARS[gear] : 1e9f;
            if (sRpm > upRpm && gear < 6 && rUp > 2300) { gear++; shiftT = 0.18f; shiftCool = 0.5f; }
            else if (sRpm < 1900 && gear > 1 && rDn < 5500) { gear--; shiftT = 0.12f; shiftCool = 0.4f; }
            else if (throttle > 0.9f && sRpm < 3000 && gear > 2 && rDn < 6000) { gear--; shiftT = 0.12f; shiftCool = 0.5f; }
        }
    }

    float gearRatio() const { return gear == -1 ? cfg::REVERSE : (gear >= 1 ? cfg::GEARS[gear] : 0.0f); }

    float damage() const {
        float s = 0; int c = 0;
        for (const Beam& bm : b) {
            if (bm.type == 1 || bm.a >= NCH || bm.b >= NCH) continue;
            s += bm.broken ? 1.0f : fminf(1.0f, fabsf(bm.rest - bm.rest0) / bm.rest0 * 6.0f);
            c++;
        }
        return c ? 100.0f * s / c : 0;
    }
    bool healthy() const {
        for (auto& nd : n) if (!finite3(nd.p) || !finite3(nd.v) || fabsf(nd.p.y) > 5000) return false;
        return true;
    }

    V3 samplePos(const std::pair<int, int>& s) const { return s.second < 0 ? n[s.first].p : (n[s.first].p + n[s.second].p) * 0.5f; }
    V3 sampleVel(const std::pair<int, int>& s) const { return s.second < 0 ? n[s.first].v : (n[s.first].v + n[s.second].v) * 0.5f; }
    void applySample(const std::pair<int, int>& s, const V3& f) {
        if (s.second < 0) n[s.first].f += f;
        else { n[s.first].f += f * 0.5f; n[s.second].f += f * 0.5f; }
    }

    // ---- ana fizik adimi ----
    void step(float dt, const std::vector<int>* nearBoxes, const World& W, const std::vector<RPoint>* remote) {
        for (auto& nd : n) nd.f = V3(0, -9.81f * nd.m, 0);
        computeFrame();

        // 1) kirisler
        for (auto& bm : b) {
            if (bm.broken) continue;
            Node &A = n[bm.a], &B = n[bm.b];
            V3 d = B.p - A.p;
            float l = len(d);
            if (l < 1e-5f) continue;
            V3 dir = d * (1.0f / l);
            float rv = dot(B.v - A.v, dir);
            float F;
            if (bm.type == 0) {
                float strain = (l - bm.rest) / bm.rest;
                if (strain > bm.yield) bm.rest = l / (1.0f + bm.yield);
                else if (strain < -bm.yield) bm.rest = std::max(l / (1.0f - bm.yield), 0.25f * bm.rest0);
                if (strain > bm.brk) { bm.broken = true; brokenCount++; continue; }
                F = bm.k * (l - bm.rest) + bm.c * rv;
            } else {
                float cdamp = rv > 0 ? bm.c * 1.3f : bm.c * 0.8f;
                F = bm.k * (l - bm.rest) + cdamp * rv;
                if (l < bm.minL) F -= 3.0e5f * (bm.minL - l);
                if (l > bm.maxL) F += 3.0e5f * (l - bm.maxL);
                if ((l - bm.rest0) / bm.rest0 > bm.brk) { bm.broken = true; brokenCount++; continue; }
            }
            V3 fv = dir * F;
            A.f += fv; B.f -= fv;
        }

        // 2) aerodinamik surtunme
        {
            float sp = len(vel);
            V3 fd = vel * (-0.5f * 1.2f * 0.65f * sp / NCH);
            for (int i = 0; i < NCH; i++) n[i].f += fd;
        }

        // 3) zemin + kutu + diger arac carpismasi (govde ornekleri)
        for (auto& s : samples) {
            V3 p = samplePos(s), v = sampleVel(s);
            float h = W.height(p.x, p.z);
            float pen = h + 0.03f - p.y;
            if (pen > 0) {
                V3 N = W.normal(p.x, p.z);
                float vn = dot(v, N);
                float Fn = std::min(3.0e5f * pen - 3000.0f * vn, 1.5e5f);
                if (Fn > 0) {
                    V3 vt = v - N * vn;
                    float vtl = len(vt);
                    V3 F = N * Fn;
                    if (vtl > 1e-4f) F += vt * (-0.55f * Fn / vtl * (vtl / (vtl + 0.3f)));
                    applySample(s, F);
                }
            }
        }
        if (nearBoxes) {
            for (int bi : *nearBoxes) {
                const Box& bx = W.boxes[bi];
                for (auto& s : samples) {
                    V3 p = samplePos(s);
                    if (fabsf(p.x - bx.c.x) > bx.h.x + bx.h.z + 1 || fabsf(p.z - bx.c.z) > bx.h.x + bx.h.z + 1) continue;
                    V3 N; float pen;
                    if (!collideBox(bx, p, 0.06f, N, pen)) continue;
                    V3 v = sampleVel(s);
                    float vn = dot(v, N);
                    float Fn = std::min(1.0e6f * pen - 6000.0f * vn, 2.5e5f);
                    if (Fn <= 0) continue;
                    V3 vt = v - N * vn; float vtl = len(vt);
                    V3 F = N * Fn;
                    if (vtl > 1e-4f) F += vt * (-0.4f * Fn / vtl * (vtl / (vtl + 0.3f)));
                    applySample(s, F);
                }
                for (int i = 0; i < 4; i++) {
                    Node& H = n[24 + i];
                    V3 N; float pen;
                    if (!collideBox(bx, H.p, cfg::WHEEL_R, N, pen)) continue;
                    float vn = dot(H.v, N);
                    float Fn = std::min(6.0e5f * pen - 4000.0f * vn, 2.0e5f);
                    if (Fn > 0) H.f += N * Fn;
                }
            }
        }
        if (remote && !remote->empty()) {
            const float RR = 0.5f;
            for (auto& s : samples) {
                V3 p = samplePos(s);
                for (auto& q : *remote) {
                    V3 d = p - q.p;
                    float d2 = dot(d, d);
                    if (d2 >= RR * RR || d2 < 1e-8f) continue;
                    float dl = sqrtf(d2);
                    V3 N = d * (1.0f / dl);
                    float vn = dot(sampleVel(s) - q.v, N);
                    float Fn = std::min(1.2e5f * (RR - dl) - 800.0f * vn, 1.0e5f);
                    if (Fn > 0) applySample(s, N * Fn);
                }
            }
        }

        // 4) tekerlekler: lastik modeli + aktarma organlari
        driveAndWheels(dt, W);

        // 5) entegrasyon
        for (auto& nd : n) {
            nd.v += nd.f * (dt / nd.m);
            nd.v *= (1.0f - 0.004f * dt);
            float sp2 = dot(nd.v, nd.v);
            if (sp2 > 150.0f * 150.0f) nd.v *= 150.0f / sqrtf(sp2);
            nd.p += nd.v * dt;
        }
        for (auto& wh : w) { wh.angle += wh.omega * dt; }
    }

    void driveAndWheels(float dt, const World& W) {
        using namespace cfg;
        const float R = WHEEL_R;
        // motor / aktarma
        float wAvg = 0.5f * (w[2].omega + w[3].omega);
        float gr = gearRatio();
        float absGr = fabsf(gr) * FINAL;
        float wheelRpmEq = fabsf(wAvg) * absGr * 9.5493f;
        float launch = IDLE + throttle * 2600.0f * (1.0f - smoothstepf(1500, 3200, wheelRpmEq));
        float target = std::max(wheelRpmEq, launch);
        rpm += (target - rpm) * std::min(1.0f, dt * 18.0f);
        float clutch = 0.62f + 0.38f * smoothstepf(900, 2800, wheelRpmEq);
        if (shiftT > 0) shiftT -= dt;
        float driveTq = 0;  // her iki arka teker toplami
        if (gr != 0) {
            float sgn = gr > 0 ? 1.0f : -1.0f;
            // cekis kontrolu: surucu tekerlerinde asiri kayma varsa motor torkunu kes
            float slipV = 0;
            for (int i = 2; i < 4; i++) slipV = std::max(slipV, (w[i].omega * R - speed * (gr > 0 ? 1.0f : -1.0f) * (gr > 0 ? 1.0f : 1.0f)) * (gr > 0 ? 1.0f : -1.0f));
            float thr = 1.0f + 0.16f * fabsf(speed);
            float tgt = tcsOn ? clampf(1.0f - (slipV - thr) * 0.7f, 0.08f, 1.0f) : 1.0f;
            tcsF += (tgt - tcsF) * std::min(1.0f, dt * 30.0f);
            float Te = engineTorque(rpm) * throttle * tcsF;
            if (rpm > REDLINE) Te = 0;
            if (shiftT > 0) Te = 0;
            driveTq = Te * absGr * clutch * 0.92f * sgn;
            // motor freni: donusu yavaslat
            float eb = (25.0f + 0.014f * rpm) * (1.0f - throttle) * absGr * clutch * 0.7f;
            float sw = clampf(wAvg / 0.5f, -1.0f, 1.0f);
            driveTq -= eb * sw;
        }
        for (int i = 0; i < 4; i++) {
            Wheel& wh = w[i];
            Node& H = n[wh.hub];
            wh.detached = b[wh.arm0].broken || b[wh.arm1].broken;
            float tq = 0;
            wh.contact = false; wh.Fn = 0; wh.slip = 0;
            float gh = W.height(H.p.x, H.p.z);
            V3 N = W.normal(H.p.x, H.p.z);
            float dist = (H.p.y - gh) * N.y;
            float pen = R - dist;
            if (pen > 0) {
                wh.contact = true;
                float vn = dot(H.v, N);
                float Fn = clampf(2.6e5f * pen - 1800.0f * vn, 0, 7.0e4f);
                wh.Fn = Fn;
                H.f += N * Fn;
                V3 fd;
                if (wh.detached) { V3 hv = H.v - N * vn; fd = len(hv) > 0.5f ? hv : fwd; }
                else {
                    float st = wh.front ? steerAngle : 0.0f;
                    fd = fwd * cosf(st) + right * sinf(st);
                }
                fd = norm(fd - N * dot(fd, N));
                V3 sd = cross(fd, N);
                float vf = dot(H.v, fd), vs = dot(H.v, sd);
                float vsl = wh.omega * R - vf;
                float u = sqrtf(vsl * vsl + vs * vs);
                float vp = 0.8f + 0.14f * fabsf(vf);
                float sg = u / vp;
                wh.slip = sg;
                float fc = tanhf(2.2f * sg) * (1.0f - 0.22f * smoothstepf(1.0f, 6.0f, sg));
                float mu = W.grip(H.p.x, H.p.z) * (wh.detached ? 0.4f : 1.0f);
                float Fm = mu * Fn * fc;
                float Fx = 0, Fs = 0;
                if (u > 1e-5f) { Fx = Fm * vsl / u; Fs = -Fm * vs / u; }
                H.f += fd * Fx + sd * Fs;
                tq -= Fx * R;
                tq -= (wh.omega > 0 ? 1.0f : -1.0f) * 0.012f * Fn * R * std::min(1.0f, fabsf(wh.omega));
            }
            if (wh.drive && !wh.detached) tq += driveTq * 0.5f;
            wh.omega += tq / WHEEL_I * dt;
            // frenler
            float bt = (wh.front ? 1800.0f : 1100.0f) * brake;
            if (!wh.front) bt += 2500.0f * inHand;
            if (bt > 0) {
                float dw = bt / WHEEL_I * dt;
                if (fabsf(wh.omega) <= dw) wh.omega = 0;
                else wh.omega -= (wh.omega > 0 ? dw : -dw);
            }
            if (wh.detached) wh.omega *= (1.0f - 0.3f * dt);
        }
    }

    void toState(proto::StateMsg& s) const {
        V3 c; for (int i = 0; i < NN; i++) c += n[i].p;
        c = c * (1.0f / NN);
        s.cx = c.x; s.cy = c.y; s.cz = c.z;
        for (int i = 0; i < NN; i++) {
            V3 o = n[i].p - c;
            s.off[i][0] = (int16_t)clampf(o.x * 1000.0f, -32000, 32000);
            s.off[i][1] = (int16_t)clampf(o.y * 1000.0f, -32000, 32000);
            s.off[i][2] = (int16_t)clampf(o.z * 1000.0f, -32000, 32000);
        }
        for (int i = 0; i < 4; i++) {
            float a = fmodf(w[i].angle, 2 * PI_F); if (a < 0) a += 2 * PI_F;
            s.wang[i] = (uint16_t)(a / (2 * PI_F) * 65535.0f);
        }
        s.steer = (int8_t)clampf(steerIn * 127.0f, -127, 127);
        s.flags = (brake > 0.2f ? proto::F_BRAKE : 0) | (gear == -1 ? proto::F_REVERSE : 0);
    }
};

inline std::vector<std::pair<int, int>> sampleTopology() {
    static std::vector<std::pair<int, int>> t;
    if (t.empty()) { Car c; c.build(V3(0, 0, 0), 0); t = c.samples; }
    return t;
}
