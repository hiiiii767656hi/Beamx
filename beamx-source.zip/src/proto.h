#pragma once
// BeamX ag protokolu (UDP). Hem istemci hem sunucu kullanir.
#include <stdint.h>
#include <string.h>
#include <string>
#include <vector>

namespace proto {
static const uint32_t MAGIC = 0x58474E42;  // 'BNGX'
static const uint8_t VERSION = 1;
static const int NODES = 28;  // 24 sasi dugumu + 4 teker
static const int NAMELEN = 16;
enum : uint8_t { HELLO = 1, WELCOME = 2, STATE = 3, RSTATE = 4, INFO = 5, LEAVE = 6, PING = 7, PONG = 8, KICK = 9, REJECT = 10 };
enum : uint8_t { F_RESPAWN = 1, F_BRAKE = 2, F_REVERSE = 4 };

struct Writer {
    std::vector<uint8_t> b;
    void u8(uint8_t v) { b.push_back(v); }
    void u16(uint16_t v) { b.push_back(v & 255); b.push_back(v >> 8); }
    void i16(int16_t v) { u16((uint16_t)v); }
    void u32(uint32_t v) { for (int i = 0; i < 4; i++) b.push_back((v >> (8 * i)) & 255); }
    void f32(float f) { uint32_t u; memcpy(&u, &f, 4); u32(u); }
    void str(const char* s, int n) { for (int i = 0; i < n; i++) b.push_back(i < (int)strlen(s) ? (uint8_t)s[i] : 0); }
    void header(uint8_t type) { u32(MAGIC); u8(type); }
};
struct Reader {
    const uint8_t* p; size_t n, i; bool ok;
    Reader(const uint8_t* d, size_t len) : p(d), n(len), i(0), ok(true) {}
    uint8_t u8() { if (i + 1 > n) { ok = false; return 0; } return p[i++]; }
    uint16_t u16() { if (i + 2 > n) { ok = false; return 0; } uint16_t v = p[i] | (p[i + 1] << 8); i += 2; return v; }
    int16_t i16() { return (int16_t)u16(); }
    uint32_t u32() { if (i + 4 > n) { ok = false; return 0; } uint32_t v = 0; for (int k = 0; k < 4; k++) v |= (uint32_t)p[i + k] << (8 * k); i += 4; return v; }
    float f32() { uint32_t u = u32(); float f; memcpy(&f, &u, 4); return f; }
    void str(char* out, int n2) { for (int k = 0; k < n2; k++) out[k] = (char)u8(); out[n2 - 1] = 0; for (int k = 0; k < n2 - 1; k++) { unsigned char c = (unsigned char)out[k]; if (c != 0 && (c < 32 || c > 126)) out[k] = '?'; } }
};

// Bir aracin tum anlik durumu. Dugum konumlari merkeze gore milimetre (int16)
struct StateMsg {
    uint8_t id = 0, color = 0, flags = 0;
    int8_t steer = 0;           // -127..127
    uint32_t seq = 0;
    float cx = 0, cy = 0, cz = 0;
    int16_t off[NODES][3];
    uint16_t wang[4];
    StateMsg() { memset(off, 0, sizeof(off)); memset(wang, 0, sizeof(wang)); }
};
inline void encodeState(Writer& w, const StateMsg& s) {
    w.u8(s.id); w.u8(s.color); w.u8(s.flags); w.u8((uint8_t)s.steer); w.u32(s.seq);
    w.f32(s.cx); w.f32(s.cy); w.f32(s.cz);
    for (int i = 0; i < NODES; i++) for (int k = 0; k < 3; k++) w.i16(s.off[i][k]);
    for (int i = 0; i < 4; i++) w.u16(s.wang[i]);
}
inline bool decodeState(Reader& r, StateMsg& s) {
    s.id = r.u8(); s.color = r.u8(); s.flags = r.u8(); s.steer = (int8_t)r.u8(); s.seq = r.u32();
    s.cx = r.f32(); s.cy = r.f32(); s.cz = r.f32();
    for (int i = 0; i < NODES; i++) for (int k = 0; k < 3; k++) s.off[i][k] = r.i16();
    for (int i = 0; i < 4; i++) s.wang[i] = r.u16();
    return r.ok;
}
}  // namespace proto
