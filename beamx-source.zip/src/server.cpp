// BeamX ozel sunucu (headless, grafik/pencere bagimliligi yok). Linux/Windows.
// Kullanim: beamx-server [--port 7777] [--name "Sunucu"] [--max 16] [--quiet]
#include <signal.h>
#include "serverlib.h"

static volatile sig_atomic_t g_run = 1;
static void onSig(int) { g_run = 0; }

int main(int argc, char** argv) {
    int port = 7777, maxP = 16; char name[25] = "BeamX Sunucu"; bool quiet = false;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--port" && i + 1 < argc) port = atoi(argv[++i]);
        else if (a == "--name" && i + 1 < argc) { strncpy(name, argv[++i], 24); name[24] = 0; }
        else if (a == "--max" && i + 1 < argc) maxP = atoi(argv[++i]);
        else if (a == "--quiet") quiet = true;
        else { printf("Kullanim: %s [--port 7777] [--name ISIM] [--max 16] [--quiet]\n", argv[0]); return a == "--help" ? 0 : 1; }
    }
    GameServer s; s.echo = true; s.quiet = quiet;
    std::string err;
    if (!s.start(port, name, maxP, err)) { fprintf(stderr, "%s\n", err.c_str()); return 1; }
    signal(SIGINT, onSig); signal(SIGTERM, onSig);
    while (g_run) {
        fd_set fds; FD_ZERO(&fds); FD_SET(s.sock, &fds);
        timeval tv; tv.tv_sec = 0; tv.tv_usec = 10000;
        select((int)s.sock + 1, &fds, nullptr, nullptr, &tv);
        s.poll(nowSec());
    }
    s.stop();
    return 0;
}
