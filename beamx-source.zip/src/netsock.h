#pragma once
// Tasinabilir UDP soket yardimcilari (Linux + Windows)
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <chrono>
#include <string>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
typedef SOCKET sock_t;
typedef int sl_t;
static const sock_t BADSOCK = INVALID_SOCKET;
#define CLOSESOCK(s) ::closesocket(s)
#else
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <unistd.h>
#include <time.h>
typedef int sock_t;
typedef socklen_t sl_t;
static const sock_t BADSOCK = -1;
#define CLOSESOCK(s) ::close(s)
#endif

inline double nowSec() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
inline void sleepMs(double ms) {
    if (ms <= 0) return;
#ifdef _WIN32
    Sleep((DWORD)ms);
#else
    timespec ts; ts.tv_sec = (time_t)(ms / 1000.0); ts.tv_nsec = (long)((ms - ts.tv_sec * 1000.0) * 1e6); nanosleep(&ts, nullptr);
#endif
}
inline bool netInit() {
#ifdef _WIN32
    WSADATA d; return WSAStartup(MAKEWORD(2, 2), &d) == 0;
#else
    return true;
#endif
}
inline bool setNonBlock(sock_t s) {
#ifdef _WIN32
    u_long m = 1; return ioctlsocket(s, FIONBIO, &m) == 0;
#else
    int f = fcntl(s, F_GETFL, 0); return f >= 0 && fcntl(s, F_SETFL, f | O_NONBLOCK) == 0;
#endif
}
inline sock_t udpSocket(int bindPort, bool nonblock = true) {
    sock_t s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == BADSOCK) return BADSOCK;
    if (bindPort >= 0) {
        int one = 1; setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&one, sizeof(one));
        sockaddr_in a; memset(&a, 0, sizeof(a)); a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_ANY); a.sin_port = htons((uint16_t)bindPort);
        if (bind(s, (sockaddr*)&a, sizeof(a)) != 0) { CLOSESOCK(s); return BADSOCK; }
    }
    if (nonblock) setNonBlock(s);
    return s;
}
inline bool resolveHost(const std::string& host, int port, sockaddr_in& out) {
    addrinfo hints; memset(&hints, 0, sizeof(hints)); hints.ai_family = AF_INET; hints.ai_socktype = SOCK_DGRAM;
    addrinfo* res = nullptr;
    if (getaddrinfo(host.c_str(), nullptr, &hints, &res) != 0 || !res) return false;
    memcpy(&out, res->ai_addr, sizeof(sockaddr_in)); out.sin_port = htons((uint16_t)port);
    freeaddrinfo(res); return true;
}
inline int recvPacket(sock_t s, uint8_t* buf, int cap, sockaddr_in& from) {
    sl_t fl = sizeof(from);
    int n = (int)recvfrom(s, (char*)buf, cap, 0, (sockaddr*)&from, &fl);
    return n;  // <0: veri yok / hata
}
inline void sendPacket(sock_t s, const sockaddr_in& to, const uint8_t* d, size_t n) { sendto(s, (const char*)d, (int)n, 0, (const sockaddr*)&to, sizeof(to)); }
inline bool sameAddr(const sockaddr_in& a, const sockaddr_in& b) { return a.sin_addr.s_addr == b.sin_addr.s_addr && a.sin_port == b.sin_port; }
inline std::string addrStr(const sockaddr_in& a) { char b[64]; snprintf(b, sizeof(b), "%s:%d", inet_ntoa(a.sin_addr), ntohs(a.sin_port)); return b; }

// Yerel agdaki IP (UDP connect hilesi: paket gonderilmez)
inline std::string localIp() {
    sock_t s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s == BADSOCK) return "127.0.0.1";
    sockaddr_in a; memset(&a, 0, sizeof(a)); a.sin_family = AF_INET; a.sin_port = htons(53); inet_pton(AF_INET, "8.8.8.8", &a.sin_addr);
    std::string r = "127.0.0.1";
    if (connect(s, (sockaddr*)&a, sizeof(a)) == 0) { sockaddr_in me; memset(&me, 0, sizeof(me)); sl_t l = sizeof(me); if (getsockname(s, (sockaddr*)&me, &l) == 0) r = inet_ntoa(me.sin_addr); }
    CLOSESOCK(s); return r;
}
