#pragma once
// BeamX sunucu cekirdegi. Hem ayri sunucu uygulamasi (server.cpp) hem de oyunun icine gomulu sunucu bunu kullanir.
// Thread yok: poll() her karede / dongude cagrilir (bloklamaz).
#include <stdarg.h>
#include <stdlib.h>
#include <time.h>
#include <cmath>
#include <deque>
#include <string>
#include <vector>
#include "netsock.h"
#include "proto.h"

struct GameServer {
    struct Client {
        bool used = false; sockaddr_in addr; uint8_t id = 0; char name[proto::NAMELEN + 1] = {0}; uint8_t color = 0;
        double lastRecv = 0, lastStateT = 0, winStart = 0; int winCount = 0; int violations = 0;
        bool hasState = false; proto::StateMsg last; uint64_t pkts = 0;
    };
    Client clients[32];
    sock_t sock = BADSOCK;
    int port = 7777, maxPlayers = 16;
    char serverName[25] = "BeamX Sunucu";
    bool running = false, echo = false, quiet = false;
    std::deque<std::string> logLines;
    uint64_t rxBytes = 0, txBytes = 0, rxPk = 0, txPk = 0;
    double lastInfo = 0, lastStat = 0;

    void log(const char* fmt, ...) {
        char msg[256]; va_list ap; va_start(ap, fmt); vsnprintf(msg, sizeof(msg), fmt, ap); va_end(ap);
        time_t t = time(nullptr); char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", localtime(&t));
        std::string line = std::string("[") + ts + "] " + msg;
        logLines.push_back(line); if (logLines.size() > 40) logLines.pop_front();
        if (echo) { printf("%s\n", line.c_str()); fflush(stdout); }
    }
    bool start(int p, const char* name, int maxP, std::string& err) {
        stop();
        netInit();
        port = p; maxPlayers = std::max(1, std::min(31, maxP));
        strncpy(serverName, name, 24); serverName[24] = 0;
        sock = udpSocket(port);
        if (sock == BADSOCK) { err = "UDP port " + std::to_string(port) + " açılamadı (başka program kullanıyor olabilir)"; return false; }
        int buf = 1 << 20; setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (const char*)&buf, sizeof(buf));
        for (auto& c : clients) c = Client();
        running = true; lastInfo = lastStat = nowSec();
        log("BeamX sunucusu basladi: \"%s\"  UDP port %d  maks %d oyuncu", serverName, port, maxPlayers);
        return true;
    }
    void stop() {
        if (!running) return;
        for (auto& k : clients) if (k.used) { proto::Writer w; w.header(proto::KICK); w.u8(3); sendTo(k.addr, w); k.used = false; }
        CLOSESOCK(sock); sock = BADSOCK; running = false;
        log("Sunucu kapatildi.");
    }
    ~GameServer() { stop(); }

    int count() const { int c = 0; for (auto& k : clients) if (k.used) c++; return c; }
    std::vector<std::string> playerNames() const { std::vector<std::string> v; for (auto& k : clients) if (k.used) v.push_back(k.name); return v; }

    void sendTo(const sockaddr_in& a, const proto::Writer& w) { sendPacket(sock, a, w.b.data(), w.b.size()); txBytes += w.b.size(); txPk++; }
    Client* find(const sockaddr_in& a) { for (auto& k : clients) if (k.used && sameAddr(k.addr, a)) return &k; return nullptr; }

    void sendInfo(const sockaddr_in* only) {
        proto::Writer w; w.header(proto::INFO); w.u8((uint8_t)count());
        for (auto& k : clients) if (k.used) { w.u8(k.id); w.u8(k.color); w.str(k.name, proto::NAMELEN); w.u8(0); }
        if (only) sendTo(*only, w); else for (auto& k : clients) if (k.used) sendTo(k.addr, w);
    }
    void dropClient(Client& k) {
        proto::Writer l; l.header(proto::LEAVE); l.u8(k.id); k.used = false;
        for (auto& o : clients) if (o.used) sendTo(o.addr, l);
    }
    void kick(Client& k, uint8_t why, const char* reason) {
        proto::Writer w; w.header(proto::KICK); w.u8(why); sendTo(k.addr, w);
        log("ATILDI %s (id %d): %s", k.name, k.id, reason);
        dropClient(k);
    }
    static bool validState(const proto::StateMsg& s) {
        if (!std::isfinite(s.cx) || !std::isfinite(s.cy) || !std::isfinite(s.cz)) return false;
        if (fabsf(s.cx) > 5000 || fabsf(s.cz) > 5000 || s.cy < -50 || s.cy > 1500) return false;
        for (int i = 0; i < proto::NODES; i++) for (int k = 0; k < 3; k++) if (abs((int)s.off[i][k]) > 15000) return false;
        return true;
    }
    void onHello(const sockaddr_in& from, proto::Reader& r, double now) {
        uint8_t ver = r.u8(), col = r.u8(); char nm[proto::NAMELEN + 1]; r.str(nm, proto::NAMELEN);
        if (!r.ok) return;
        Client* ex = find(from); Client* c = ex;
        if (!c) {
            if (ver != proto::VERSION) { proto::Writer w; w.header(proto::REJECT); w.u8(2); sendTo(from, w); return; }
            if (count() >= maxPlayers) { proto::Writer w; w.header(proto::REJECT); w.u8(1); sendTo(from, w); log("Reddedildi %s: sunucu dolu", addrStr(from).c_str()); return; }
            for (int i = 1; i < 32; i++) if (!clients[i].used) { c = &clients[i]; break; }
            if (!c) return;
            int id = (int)(c - clients);
            *c = Client(); c->id = (uint8_t)id; c->used = true; c->addr = from;
            char clean[proto::NAMELEN + 1]; int n = 0;
            for (int i = 0; nm[i] && n < proto::NAMELEN - 1; i++) if (nm[i] >= 33 && nm[i] <= 126) clean[n++] = nm[i];
            if (n == 0) { strcpy(clean, "Oyuncu"); n = 6; }
            clean[n] = 0;
            char fin[proto::NAMELEN + 1]; strcpy(fin, clean); int suffix = 1;
            for (bool dup = true; dup;) {
                dup = false;
                for (auto& o : clients) if (o.used && &o != c && strcmp(o.name, fin) == 0) { dup = true; break; }
                if (dup) snprintf(fin, sizeof(fin), "%.10s%d", clean, ++suffix);
            }
            strcpy(c->name, fin); c->color = col & 7;
            log("KATILDI %s (id %d) %s  [%d/%d]", c->name, c->id, addrStr(from).c_str(), count(), maxPlayers);
        }
        c->lastRecv = now;
        proto::Writer w; w.header(proto::WELCOME); w.u8(c->id); w.u8((uint8_t)maxPlayers); w.str(serverName, 25); sendTo(from, w);
        if (!ex) {
            sendInfo(nullptr);
            for (auto& o : clients) if (o.used && o.hasState && &o != c) {
                proto::Writer sw; sw.header(proto::RSTATE); proto::StateMsg m = o.last; m.id = o.id; proto::encodeState(sw, m); sendTo(from, sw);
            }
        }
    }
    void onState(Client& c, proto::Reader& r, double now) {
        proto::StateMsg s;
        if (!proto::decodeState(r, s)) return;
        if (now - c.winStart > 1.0) { c.winStart = now; c.winCount = 0; }
        if (++c.winCount > 80) return;
        if (!validState(s)) { if (++c.violations > 8) kick(c, 1, "gecersiz durum verisi"); return; }
        if (c.hasState && !(s.flags & proto::F_RESPAWN)) {
            double dt = now - c.lastStateT;
            if (dt > 0.004) {
                float dx = s.cx - c.last.cx, dy = s.cy - c.last.cy, dz = s.cz - c.last.cz;
                float d = sqrtf(dx * dx + dy * dy + dz * dz);
                if (d / dt > 160.0) { if (++c.violations > 8) kick(c, 2, "isinlanma/hiz hilesi suphesi"); return; }
                else if (c.violations > 0 && (c.pkts % 50) == 0) c.violations--;
            }
        }
        c.pkts++;
        s.id = c.id; s.color = c.color; c.last = s; c.hasState = true; c.lastStateT = now; c.lastRecv = now;
        proto::Writer w; w.header(proto::RSTATE); proto::encodeState(w, s);
        for (auto& o : clients) if (o.used && &o != &c) sendTo(o.addr, w);
    }

    // bloklamaz: bekleyen tum paketleri isler + zaman asimi/istatistik
    void poll(double now) {
        if (!running) return;
        uint8_t buf[2048];
        for (int guard = 0; guard < 4000; guard++) {
            sockaddr_in from; int n = recvPacket(sock, buf, sizeof(buf), from);
            if (n <= 0) break;
            rxBytes += n; rxPk++;
            proto::Reader r(buf, n);
            if (r.u32() != proto::MAGIC) continue;
            uint8_t type = r.u8();
            if (type == proto::HELLO) { onHello(from, r, now); continue; }
            Client* c = find(from);
            if (!c) continue;
            c->lastRecv = now;
            if (type == proto::STATE) onState(*c, r, now);
            else if (type == proto::PING) { uint32_t t = r.u32(); proto::Writer w; w.header(proto::PONG); w.u32(t); sendTo(from, w); }
            else if (type == proto::LEAVE) { log("AYRILDI %s (id %d)  [%d/%d]", c->name, c->id, count() - 1, maxPlayers); dropClient(*c); }
        }
        for (auto& k : clients) if (k.used && now - k.lastRecv > 8.0) { log("ZAMAN ASIMI %s (id %d)  [%d/%d]", k.name, k.id, count() - 1, maxPlayers); dropClient(k); }
        if (now - lastInfo > 3.0) { lastInfo = now; if (count()) sendInfo(nullptr); }
        if (!quiet && now - lastStat > 30.0) {
            double dt = now - lastStat; lastStat = now;
            log("durum: %d oyuncu, gelen %.0f pkt/s %.1f KB/s, giden %.0f pkt/s %.1f KB/s", count(), rxPk / dt, rxBytes / dt / 1024, txPk / dt, txBytes / dt / 1024);
            rxPk = txPk = rxBytes = txBytes = 0;
        }
    }
};
