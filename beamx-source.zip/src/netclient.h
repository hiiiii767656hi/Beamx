#pragma once
#include <deque>
#include <string>
#include "netsock.h"
#include "proto.h"
#include "vec.h"

struct Snap { double t; V3 p[proto::NODES]; float wang[4]; float steer; uint8_t flags; };
struct Remote {
    bool active = false, known = false;
    char name[proto::NAMELEN + 1] = {0};
    uint8_t color = 0;
    std::deque<Snap> snaps;
    double lastT = 0;
};

struct NetClient {
    sock_t s = BADSOCK;
    sockaddr_in srv;
    bool started = false, connected = false, failed = false;
    std::string status, serverName;
    uint8_t myId = 0, maxPlayers = 0;
    char name[proto::NAMELEN + 1] = {0};
    uint8_t color = 0;
    double tHello = 0, tPing = 0, tLastRecv = 0, tStart = 0, tSend = 0;
    int pingMs = 0; uint32_t seq = 0;
    uint64_t rx = 0, tx = 0;
    Remote remotes[32];

    bool begin(const std::string& hostport, const char* nm, uint8_t col) {
        close();
        std::string host = hostport; int port = 7777;
        size_t c = host.rfind(':');
        if (c != std::string::npos) { port = atoi(host.c_str() + c + 1); host = host.substr(0, c); }
        if (host.empty()) host = "127.0.0.1";
        if (port <= 0 || port > 65535) { status = "Geçersiz port"; failed = true; return false; }
        if (!netInit()) { status = "Ağ başlatılamadı"; failed = true; return false; }
        if (!resolveHost(host, port, srv)) { status = "Sunucu adresi çözülemedi: " + host; failed = true; return false; }
        s = udpSocket(0);
        if (s == BADSOCK) { status = "Soket açılamadı"; failed = true; return false; }
        strncpy(name, nm, proto::NAMELEN); name[proto::NAMELEN] = 0; color = col;
        started = true; connected = false; failed = false; status = "Bağlanıyor...";
        tStart = nowSec(); tHello = 0; tLastRecv = tStart; rx = tx = 0; seq = 0;
        for (auto& r : remotes) r = Remote();
        return true;
    }
    void close() {
        if (s != BADSOCK) {
            if (connected) { proto::Writer w; w.header(proto::LEAVE); w.u8(myId); send(w); }
            CLOSESOCK(s); s = BADSOCK;
        }
        started = connected = false;
    }
    void send(const proto::Writer& w) { if (s != BADSOCK) { sendPacket(s, srv, w.b.data(), w.b.size()); tx++; } }

    void update(double now) {
        if (!started) return;
        uint8_t buf[2048]; sockaddr_in from;
        for (;;) {
            int n = recvPacket(s, buf, sizeof(buf), from);
            if (n <= 0) break;
            if (!sameAddr(from, srv)) continue;
            handle(buf, n, now);
        }
        if (!connected) {
            if (now - tStart > 6.0) { failed = true; started = false; status = "Sunucuya ulaşılamadı (zaman aşımı)"; return; }
            if (now - tHello > 0.5) {
                tHello = now;
                proto::Writer w; w.header(proto::HELLO); w.u8(proto::VERSION); w.u8(color); w.str(name, proto::NAMELEN);
                send(w);
            }
        } else {
            if (now - tPing > 1.0) { tPing = now; proto::Writer w; w.header(proto::PING); w.u32((uint32_t)(now * 1000.0)); send(w); }
            if (now - tLastRecv > 8.0) { connected = false; started = false; failed = true; status = "Bağlantı koptu"; }
            for (auto& r : remotes) if (r.active && now - r.lastT > 5.0) r.active = false;
        }
    }
    void handle(const uint8_t* d, int n, double now) {
        proto::Reader r(d, n);
        if (r.u32() != proto::MAGIC) return;
        uint8_t type = r.u8();
        tLastRecv = now; rx++;
        switch (type) {
            case proto::WELCOME: {
                myId = r.u8(); maxPlayers = r.u8(); char sn[25]; r.str(sn, 25);
                if (r.ok) { serverName = sn; connected = true; status = "Bağlandı"; }
                break;
            }
            case proto::REJECT: {
                uint8_t why = r.u8();
                failed = true; started = false;
                status = why == 1 ? "Sunucu dolu" : why == 2 ? "Sürüm uyumsuz" : "Reddedildi";
                break;
            }
            case proto::KICK: { uint8_t why = r.u8(); connected = false; started = false; failed = true; status = why == 3 ? "Sunucu kapandı" : "Sunucudan atıldınız (geçersiz hareket)"; break; }
            case proto::RSTATE: {
                proto::StateMsg m;
                if (!proto::decodeState(r, m) || m.id == 0 || m.id >= 32 || m.id == myId) break;
                Remote& rm = remotes[m.id];
                rm.known = true; rm.color = m.color;
                if (!rm.active) rm.snaps.clear();
                rm.active = true; rm.lastT = now;
                if (m.flags & proto::F_RESPAWN) rm.snaps.clear();
                Snap sn; sn.t = now; sn.flags = m.flags; sn.steer = m.steer / 127.0f * 0.5f;
                for (int i = 0; i < proto::NODES; i++) sn.p[i] = V3(m.cx + m.off[i][0] * 0.001f, m.cy + m.off[i][1] * 0.001f, m.cz + m.off[i][2] * 0.001f);
                for (int i = 0; i < 4; i++) sn.wang[i] = m.wang[i] / 65535.0f * 2 * PI_F;
                rm.snaps.push_back(sn);
                while (rm.snaps.size() > 12) rm.snaps.pop_front();
                break;
            }
            case proto::INFO: {
                int cnt = r.u8();
                for (int i = 0; i < cnt && r.ok; i++) {
                    uint8_t id = r.u8(), col = r.u8(); char nm[proto::NAMELEN + 1]; r.str(nm, proto::NAMELEN + 1);
                    if (!r.ok || id == 0 || id >= 32 || id == myId) continue;
                    strncpy(remotes[id].name, nm, proto::NAMELEN); remotes[id].name[proto::NAMELEN] = 0;
                    remotes[id].color = col; remotes[id].known = true;
                }
                break;
            }
            case proto::LEAVE: { uint8_t id = r.u8(); if (id < 32) remotes[id] = Remote(); break; }
            case proto::PONG: { uint32_t t = r.u32(); if (r.ok) { int p = (int)((uint32_t)(now * 1000.0) - t); if (p >= 0 && p < 10000) pingMs = p; } break; }
        }
    }
    void sendState(proto::StateMsg& m) {
        if (!connected) return;
        m.id = myId; m.color = color; m.seq = ++seq;
        proto::Writer w; w.header(proto::STATE); proto::encodeState(w, m); send(w);
    }
    int activeCount() const { int c = 0; for (auto& r : remotes) if (r.active) c++; return c; }

    // Uzak araci (now - gecikme) zamaninda enterpole et
    bool interp(int id, double now, V3* out, V3* vel, float* wang, float& steer, uint8_t& flags) const {
        const Remote& r = remotes[id];
        if (!r.active || r.snaps.empty()) return false;
        double rt = now - 0.10;
        const Snap* a = &r.snaps.front(); const Snap* b = a;
        bool found = false;
        for (size_t i = 0; i + 1 < r.snaps.size(); i++)
            if (r.snaps[i].t <= rt && rt <= r.snaps[i + 1].t) { a = &r.snaps[i]; b = &r.snaps[i + 1]; found = true; break; }
        steer = r.snaps.back().steer; flags = r.snaps.back().flags;
        if (!found) {
            const Snap& last = r.snaps.back();
            if (rt > last.t) {
                if (r.snaps.size() >= 2) {
                    const Snap& prev = r.snaps[r.snaps.size() - 2];
                    double dt = last.t - prev.t; if (dt < 1e-3) dt = 1e-3;
                    double ex = std::min(rt - last.t, 0.25);
                    for (int i = 0; i < proto::NODES; i++) { V3 v = (last.p[i] - prev.p[i]) * (float)(1.0 / dt); out[i] = last.p[i] + v * (float)ex; vel[i] = v; }
                } else for (int i = 0; i < proto::NODES; i++) { out[i] = last.p[i]; vel[i] = V3(); }
                for (int i = 0; i < 4; i++) wang[i] = last.wang[i];
            } else {
                const Snap& f = r.snaps.front();
                for (int i = 0; i < proto::NODES; i++) { out[i] = f.p[i]; vel[i] = V3(); }
                for (int i = 0; i < 4; i++) wang[i] = f.wang[i];
            }
            return true;
        }
        double dt = b->t - a->t; float t = dt > 1e-6 ? (float)((rt - a->t) / dt) : 0;
        for (int i = 0; i < proto::NODES; i++) { out[i] = lerp3(a->p[i], b->p[i], t); vel[i] = dt > 1e-6 ? (b->p[i] - a->p[i]) * (float)(1.0 / dt) : V3(); }
        for (int i = 0; i < 4; i++) {
            float d = b->wang[i] - a->wang[i];
            while (d > PI_F) d -= 2 * PI_F; while (d < -PI_F) d += 2 * PI_F;
            wang[i] = a->wang[i] + d * t;
        }
        return true;
    }
};
