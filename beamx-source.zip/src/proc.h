#pragma once
// Harici programi (playit.gg ajani) bulup arka planda calistirir, ciktisini okur.
// Linux + Windows. Android'de devre disi.
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <string>
#include <vector>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shellapi.h>
#elif !defined(__ANDROID__)
#include <dirent.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

inline std::string lowerStr(std::string s) { for (auto& c : s) if (c >= 'A' && c <= 'Z') c += 32; return s; }
inline bool endsWith(const std::string& s, const std::string& e) { return s.size() >= e.size() && s.compare(s.size() - e.size(), e.size(), e) == 0; }
inline bool looksLikePlayit(const std::string& name) {
    std::string n = lowerStr(name);
    if (n.compare(0, 6, "playit") != 0) return false;
    static const char* bad[] = {".txt", ".log", ".toml", ".md", ".zip", ".gz", ".tar", ".sig", ".json", ".yml", ".cpp", ".h", ".dll"};
    for (auto b : bad) if (endsWith(n, b)) return false;
#ifdef _WIN32
    return endsWith(n, ".exe");
#else
    return true;
#endif
}

struct ProcRunner {
    bool started = false;
    std::string exe;
#if defined(_WIN32)
    HANDLE hProc = nullptr, hRead = nullptr;
#elif !defined(__ANDROID__)
    pid_t pid = -1; int fd = -1;
#endif

    static bool supported() {
#if defined(__ANDROID__)
        return false;
#else
        return true;
#endif
    }

    // playit programini ara: oyunun klasoru, calisma klasoru, PATH
    static std::string findPlayit() {
#if defined(__ANDROID__)
        return "";
#elif defined(_WIN32)
        std::vector<std::string> dirs;
        char buf[MAX_PATH]; DWORD n = GetModuleFileNameA(nullptr, buf, MAX_PATH);
        if (n > 0 && n < MAX_PATH) { std::string p(buf, n); size_t k = p.find_last_of("\\/"); if (k != std::string::npos) dirs.push_back(p.substr(0, k)); }
        dirs.push_back(".");
        for (auto& d : dirs) {
            WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA((d + "\\playit*").c_str(), &fd);
            if (h == INVALID_HANDLE_VALUE) continue;
            do { if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && looksLikePlayit(fd.cFileName)) { FindClose(h); return d + "\\" + fd.cFileName; } } while (FindNextFileA(h, &fd));
            FindClose(h);
        }
        char out[MAX_PATH]; if (SearchPathA(nullptr, "playit.exe", nullptr, MAX_PATH, out, nullptr)) return out;
        return "";
#else
        std::vector<std::string> dirs;
        char buf[4096]; ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
        if (n > 0) { buf[n] = 0; std::string p(buf); size_t k = p.find_last_of('/'); if (k != std::string::npos) dirs.push_back(p.substr(0, k)); }
        dirs.push_back(".");
        const char* home = getenv("HOME"); if (home) { dirs.push_back(std::string(home) + "/.local/bin"); dirs.push_back(std::string(home) + "/playit"); }
        const char* path = getenv("PATH");
        if (path) { std::string ps = path; size_t a = 0; while (a <= ps.size()) { size_t b = ps.find(':', a); if (b == std::string::npos) b = ps.size(); if (b > a) dirs.push_back(ps.substr(a, b - a)); a = b + 1; } }
        for (auto& d : dirs) {
            DIR* dp = opendir(d.c_str()); if (!dp) continue;
            while (dirent* e = readdir(dp)) {
                if (!looksLikePlayit(e->d_name)) continue;
                std::string full = d + "/" + e->d_name; struct stat st;
                if (stat(full.c_str(), &st) == 0 && S_ISREG(st.st_mode) && access(full.c_str(), X_OK) == 0) { closedir(dp); return full; }
            }
            closedir(dp);
        }
        return "";
#endif
    }

    bool start(const std::string& exePath, const std::vector<std::string>& args) {
        stop(); exe = exePath;
#if defined(__ANDROID__)
        (void)args; return false;
#elif defined(_WIN32)
        SECURITY_ATTRIBUTES sa; sa.nLength = sizeof(sa); sa.bInheritHandle = TRUE; sa.lpSecurityDescriptor = nullptr;
        HANDLE rd, wr; if (!CreatePipe(&rd, &wr, &sa, 0)) return false;
        SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
        STARTUPINFOA si; memset(&si, 0, sizeof(si)); si.cb = sizeof(si); si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
        si.hStdOutput = wr; si.hStdError = wr; si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
        std::string cmd = "\"" + exePath + "\""; for (auto& a : args) cmd += " " + a;
        PROCESS_INFORMATION pi; memset(&pi, 0, sizeof(pi));
        std::vector<char> c(cmd.begin(), cmd.end()); c.push_back(0);
        BOOL ok = CreateProcessA(nullptr, c.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
        CloseHandle(wr);
        if (!ok) { CloseHandle(rd); return false; }
        CloseHandle(pi.hThread); hProc = pi.hProcess; hRead = rd; started = true; return true;
#else
        int p[2]; if (pipe(p) != 0) return false;
        pid_t pd = fork();
        if (pd < 0) { close(p[0]); close(p[1]); return false; }
        if (pd == 0) {
            dup2(p[1], 1); dup2(p[1], 2); close(p[0]); close(p[1]);
            int nul = open("/dev/null", O_RDONLY); if (nul >= 0) { dup2(nul, 0); close(nul); }
            setenv("TERM", "dumb", 1); setenv("NO_COLOR", "1", 1);
            std::vector<char*> av; av.push_back((char*)exePath.c_str());
            for (auto& a : args) av.push_back((char*)a.c_str());
            av.push_back(nullptr);
            execv(exePath.c_str(), av.data());
            _exit(127);
        }
        close(p[1]); fcntl(p[0], F_SETFL, fcntl(p[0], F_GETFL, 0) | O_NONBLOCK);
        pid = pd; fd = p[0]; started = true; return true;
#endif
    }
    bool alive() {
        if (!started) return false;
#if defined(__ANDROID__)
        return false;
#elif defined(_WIN32)
        return WaitForSingleObject(hProc, 0) == WAIT_TIMEOUT;
#else
        int st; pid_t r = waitpid(pid, &st, WNOHANG);
        return r == 0;
#endif
    }
    // son cagridan beri gelen cikti (bloklamaz)
    std::string readOutput() {
        std::string out;
        if (!started) return out;
#if defined(__ANDROID__)
#elif defined(_WIN32)
        DWORD avail = 0;
        while (PeekNamedPipe(hRead, nullptr, 0, nullptr, &avail, nullptr) && avail > 0) {
            char b[1024]; DWORD got = 0;
            if (!ReadFile(hRead, b, (DWORD)std::min<DWORD>(avail, sizeof(b)), &got, nullptr) || got == 0) break;
            out.append(b, got);
        }
#else
        char b[1024]; ssize_t n;
        while ((n = read(fd, b, sizeof(b))) > 0) out.append(b, (size_t)n);
#endif
        return out;
    }
    void stop() {
        if (!started) return;
#if defined(_WIN32)
        TerminateProcess(hProc, 0); CloseHandle(hProc); CloseHandle(hRead); hProc = hRead = nullptr;
#elif !defined(__ANDROID__)
        kill(pid, SIGTERM);
        for (int i = 0; i < 20; i++) { int st; if (waitpid(pid, &st, WNOHANG) != 0) break; usleep(25000); if (i == 19) { kill(pid, SIGKILL); waitpid(pid, &st, 0); } }
        close(fd); fd = -1; pid = -1;
#endif
        started = false;
    }
    ~ProcRunner() { stop(); }
};

inline void openUrl(const std::string& url) {
#if defined(__ANDROID__)
    (void)url;
#elif defined(_WIN32)
    ShellExecuteA(nullptr, "open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#else
    pid_t pd = fork();
    if (pd == 0) {
        int nul = open("/dev/null", O_RDWR); if (nul >= 0) { dup2(nul, 0); dup2(nul, 1); dup2(nul, 2); }
        execlp("xdg-open", "xdg-open", url.c_str(), (char*)nullptr);
        _exit(127);
    } else if (pd > 0) {
        // zombie birakma: ayri iplikte beklemeden, SIGCHLD yok sayilmasin diye hemen waitpid(WNOHANG) denenir
        int st; waitpid(pd, &st, WNOHANG);
    }
#endif
}
