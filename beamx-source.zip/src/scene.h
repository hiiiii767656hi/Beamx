#pragma once
// Sahne cizimi: arazi, engeller, arac govdesi, tekerlekler, golge
#include "car.h"
#include "render.h"
#include "world.h"

static const uint32_t PALETTE[8] = {0xC82020, 0x2050C8, 0xE6BE1E, 0x1E9646, 0xE1E1E6, 0x232328, 0xEB7319, 0x8232AA};
static const char* const PALETTE_NAME[8] = {"Kırmızı", "Mavi", "Sarı", "Yeşil", "Beyaz", "Siyah", "Turuncu", "Mor"};

struct CarView {
    V3 p[proto::NODES];
    float wang[4] = {0, 0, 0, 0};
    float steer = 0;
    uint32_t color = 0xC82020;
    bool brake = false, reverse = false;
};

inline float hash2(int x, int z) {
    uint32_t h = (uint32_t)x * 374761393u + (uint32_t)z * 668265263u;
    h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16;
    return (h & 0xFFFFFF) / 16777216.0f;
}

inline void frameOfNodes(const V3* p, V3& fwd, V3& right, V3& up, V3& cen) {
    V3 fr, rr, Rg, Lf;
    for (int c = 0; c < 4; c++) { fr += p[ix(4, c)] + p[ix(5, c)]; rr += p[ix(0, c)] + p[ix(1, c)]; }
    V3 f0 = norm(fr * 0.125f - rr * 0.125f);
    for (int s = 0; s < 6; s++) { Rg += p[ix(s, 1)] + p[ix(s, 3)]; Lf += p[ix(s, 0)] + p[ix(s, 2)]; }
    V3 rv = Rg * (1.0f / 12) - Lf * (1.0f / 12);
    up = norm(cross(rv, f0)); right = norm(cross(f0, up)); fwd = norm(cross(up, right));
    V3 c; for (int i = 0; i < 24; i++) c += p[i]; cen = c * (1.0f / 24);
}

// ---------------- arazi ----------------
inline uint32_t groundColor(float x, float z, float cs, float slope, float h, int ix_, int iz_) {
    float d = fmaxf(fabsf(x), fabsf(z));
    float nz = hash2(ix_, iz_);
    if (d < 258) {
        // rampa
        if (x > 69 && x < 96 && fabsf(z) < 6.5f) return rgb(168 + (int)(nz * 6), 160 + (int)(nz * 6), 138);
        int base = 58 + (int)(nz * 5) + (((ix_ + iz_) & 1) ? 3 : 0);
        uint32_t c = rgb(base, base + 1, base + 3);
        if (cs <= 2.01f) {
            float mx = fmodf(fabsf(x) + 2000.0f, 40.0f), mz = fmodf(fabsf(z) + 2000.0f, 40.0f);
            if (mx < cs || mz < cs) c = rgb(205, 205, 200);
            else if (fabsf(z) < 0.5f && fmodf(fabsf(x) + 2000.0f, 8.0f) < 4.0f) c = rgb(215, 190, 40);
        }
        return c;
    }
    if (slope > 0.55f) return rgb(112 + (int)(nz * 14), 106 + (int)(nz * 12), 98);
    float t = clampf(0.35f + 0.6f * nz + h * 0.01f, 0, 1);
    return mixc(rgb(74, 108, 48), rgb(134, 112, 70), t);
}

inline void drawGrid(Renderer& R, const V3& cam, float cs, int half, bool skipInner, float innerHalf, float drop) {
    int n = 2 * half + 1;
    static std::vector<float> hv;
    hv.resize((size_t)n * n);
    float gx0 = floorf(cam.x / cs) * cs - half * cs, gz0 = floorf(cam.z / cs) * cs - half * cs;
    for (int j = 0; j < n; j++)
        for (int i = 0; i < n; i++) hv[(size_t)j * n + i] = World::height(gx0 + i * cs, gz0 + j * cs) - drop;
    float tanH = (R.W * 0.5f) / R.focal * 1.15f + 0.1f;
    for (int j = 0; j < n - 1; j++)
        for (int i = 0; i < n - 1; i++) {
            float x0 = gx0 + i * cs, z0 = gz0 + j * cs, xc = x0 + cs * 0.5f, zc = z0 + cs * 0.5f;
            if (skipInner && fabsf(xc - cam.x) < innerHalf && fabsf(zc - cam.z) < innerHalf) continue;
            float dcx = xc - R.cp.x, dcz = zc - R.cp.z;
            float fz = dcx * R.cf.x + dcz * R.cf.z, fx = dcx * R.cr.x + dcz * R.cr.z;
            float cull = cs * 1.8f;
            if (fz < -cull) continue;
            if (fabsf(fx) > fz * tanH * 1.5f + cull * 2.5f) continue;
            float h00 = hv[(size_t)j * n + i], h10 = hv[(size_t)j * n + i + 1], h01 = hv[(size_t)(j + 1) * n + i], h11 = hv[(size_t)(j + 1) * n + i + 1];
            float nx = (h00 + h01 - h10 - h11) / (2 * cs), nzz = (h00 + h10 - h01 - h11) / (2 * cs);
            V3 N = norm(V3(nx, 1, nzz));
            float slope = sqrtf(nx * nx + nzz * nzz);
            uint32_t col = groundColor(xc, zc, cs, slope, (h00 + h11) * 0.5f, (int)floorf(xc / cs), (int)floorf(zc / cs));
            float lit = 0.46f + 0.54f * std::max(0.0f, dot(N, R.sun));
            col = scalec(col, lit);
            V3 a(x0, h00, z0), b(x0 + cs, h10, z0), c(x0 + cs, h11, z0 + cs), d(x0, h01, z0 + cs);
            R.tri(a, d, c, col); R.tri(a, c, b, col);
        }
}

inline void drawTerrain(Renderer& R, const V3& cam) {
    drawGrid(R, cam, 8.0f, 60, true, 64.0f, 0.45f);
    drawGrid(R, cam, 2.0f, 32, false, 0, 0);
}

inline void drawBoxes(Renderer& R, const World& W) {
    for (const Box& b : W.boxes) {
        float dx = b.c.x - R.cp.x, dz = b.c.z - R.cp.z;
        if (dx * dx + dz * dz > 450.0f * 450.0f) continue;
        if (dx * R.cf.x + dz * R.cf.z < -(b.h.x + b.h.z) * 1.5f) continue;
        V3 c[8];
        for (int i = 0; i < 8; i++) {
            V3 l((i & 1) ? b.h.x : -b.h.x, (i & 2) ? b.h.y : -b.h.y, (i & 4) ? b.h.z : -b.h.z);
            c[i] = b.c + b.toWorldDir(l);
        }
        struct F { int a, b, c, d; V3 n; };
        V3 ex = b.toWorldDir(V3(1, 0, 0)), ez = b.toWorldDir(V3(0, 0, 1));
        F fs[6] = {{0, 2, 6, 4, -ex}, {1, 5, 7, 3, ex}, {0, 4, 5, 1, V3(0, -1, 0)}, {2, 3, 7, 6, V3(0, 1, 0)}, {0, 1, 3, 2, -ez}, {4, 6, 7, 5, ez}};
        for (auto& f : fs) {
            float l = 0.45f + 0.55f * std::max(0.0f, dot(f.n, R.sun));
            R.quad(c[f.a], c[f.b], c[f.c], c[f.d], scalec(b.col, l));
        }
    }
}

// ---------------- arac ----------------
inline void drawCarShadow(Renderer& R, const CarView& cv) {
    int idx[4][2] = {{0, 0}, {0, 1}, {5, 1}, {5, 0}};
    V3 q[4];
    for (int i = 0; i < 4; i++) {
        V3 p = cv.p[ix(idx[i][0], idx[i][1])];
        float g = World::height(p.x, p.z);
        q[i] = V3(p.x + (p.y - g) * -0.25f, g + 0.04f, p.z + (p.y - g) * -0.15f);
    }
    R.quad(q[0], q[1], q[2], q[3], rgb(0, 0, 0), 0.38f, true, 0.0f);
}

inline void drawWheel(Renderer& R, V3 H, const V3& fwd, const V3& right, float angle, float steer, bool front, bool leftSide) {
    H = H + right * (leftSide ? 0.14f : -0.14f);
    const int N = 14;
    const float RAD = cfg::WHEEL_R, HW = 0.105f;
    V3 fw = front ? fwd * cosf(steer) + right * sinf(steer) : fwd;
    V3 ax = norm(cross(fw, norm(cross(right, fwd))));   // yaklasik dingil yonu
    ax = right;
    fw = norm(fw - ax * dot(fw, ax));
    V3 uu = cross(ax, fw);
    V3 ring[N][2], rim[N][2];
    for (int k = 0; k < N; k++) {
        float th = -angle + k * (2 * PI_F / N);
        V3 d = fw * cosf(th) + uu * sinf(th);
        for (int s = 0; s < 2; s++) {
            V3 o = ax * (s ? HW : -HW);
            ring[k][s] = H + d * RAD + o;
            rim[k][s] = H + d * (RAD * 0.62f) + o * 1.05f;
        }
    }
    uint32_t tire = rgb(30, 30, 34), tire2 = rgb(44, 44, 48), side = rgb(38, 38, 42);
    for (int k = 0; k < N; k++) {
        int k2 = (k + 1) % N;
        V3 mid = (ring[k][0] + ring[k2][1]) * 0.5f - H;
        float l = 0.55f + 0.45f * std::max(0.0f, dot(norm(mid), R.sun));
        R.quad(ring[k][0], ring[k2][0], ring[k2][1], ring[k][1], scalec((k & 1) ? tire : tire2, l));
        for (int s = 0; s < 2; s++) {
            V3 n = ax * (s ? 1.0f : -1.0f);
            float ls = 0.5f + 0.5f * std::max(0.0f, dot(n, R.sun));
            R.quad(ring[k][s], ring[k2][s], rim[k2][s], rim[k][s], scalec(side, ls));
            uint32_t rc = (k & 1) ? rgb(176, 180, 190) : rgb(110, 114, 124);
            V3 cen = H + ax * ((s ? HW : -HW) * 1.05f);
            R.tri(cen, rim[k][s], rim[k2][s], scalec(rc, ls));
        }
    }
}

inline void drawCar(Renderer& R, const CarView& cv) {
    V3 fwd, right, up, cen;
    frameOfNodes(cv.p, fwd, right, up, cen);
    auto P = [&](int s, int c) -> const V3& { return cv.p[ix(s, c)]; };
    auto lit = [&](V3 n, uint32_t col) { n = norm(n); float f = 0.40f + 0.60f * std::max(0.0f, dot(n, R.sun)) + 0.10f * n.y; return scalec(col, f); };
    auto face = [&](const V3& a, const V3& b, const V3& c, const V3& d, uint32_t col) {
        V3 n = cross(b - a, d - a); V3 mid = (a + b + c + d) * 0.25f;
        if (dot(n, mid - cen) < 0) n = -n;
        R.quad(a, b, c, d, lit(n, col));
    };
    uint32_t body = cv.color, glass = rgb(34, 48, 66), dark = rgb(26, 26, 30);
    for (int s = 0; s < 5; s++) {
        face(P(s, 0), P(s + 1, 0), P(s + 1, 2), P(s, 2), body);
        face(P(s, 1), P(s + 1, 1), P(s + 1, 3), P(s, 3), body);
        face(P(s, 2), P(s + 1, 2), P(s + 1, 3), P(s, 3), (s == 1 || s == 3) ? glass : body);
        face(P(s, 0), P(s + 1, 0), P(s + 1, 1), P(s, 1), dark);
    }
    face(P(0, 0), P(0, 1), P(0, 3), P(0, 2), scalec(body, 0.85f));
    face(P(5, 0), P(5, 1), P(5, 3), P(5, 2), scalec(body, 0.9f));
    // yan camlar
    for (int side = 0; side < 2; side++) {
        for (int s = 1; s <= 3; s++) {
            int c0 = side ? 1 : 0, c1 = side ? 3 : 2;
            V3 a = P(s, c0), b = P(s + 1, c0), c = P(s + 1, c1), d = P(s, c1);
            float u0, u1, v0, v1;
            if (s == 1) { u0 = 0.32f; u1 = 0.92f; v0 = 0.50f; v1 = 0.90f; }
            else if (s == 2) { u0 = 0.05f; u1 = 0.95f; v0 = 0.55f; v1 = 0.92f; }
            else { u0 = 0.06f; u1 = 0.58f; v0 = 0.50f; v1 = 0.88f; }
            auto bil = [&](float u, float v) { return lerp3(lerp3(a, b, u), lerp3(d, c, u), v); };
            V3 off = norm(cross(b - a, d - a)); if (dot(off, (a + b + c + d) * 0.25f - cen) < 0) off = -off; off = off * 0.015f;
            R.quad(bil(u0, v0) + off, bil(u1, v0) + off, bil(u1, v1) + off, bil(u0, v1) + off, lit(off, glass), 1.0f, true, 0.0004f);
        }
    }
    // farlar / stop lambalari
    {
        V3 a = P(5, 0), b = P(5, 1), c = P(5, 3), d = P(5, 2);
        auto bil = [&](float u, float v) { return lerp3(lerp3(a, b, u), lerp3(d, c, u), v); };
        V3 off = fwd * 0.015f;
        uint32_t hl = rgb(255, 248, 210);
        R.quad(bil(0.06f, 0.45f) + off, bil(0.30f, 0.45f) + off, bil(0.30f, 0.80f) + off, bil(0.06f, 0.80f) + off, hl, 1.0f, true, 0.0004f);
        R.quad(bil(0.70f, 0.45f) + off, bil(0.94f, 0.45f) + off, bil(0.94f, 0.80f) + off, bil(0.70f, 0.80f) + off, hl, 1.0f, true, 0.0004f);
        R.quad(bil(0.36f, 0.25f) + off, bil(0.64f, 0.25f) + off, bil(0.64f, 0.55f) + off, bil(0.36f, 0.55f) + off, rgb(20, 20, 22), 1.0f, true, 0.0004f);
        V3 a2 = P(0, 0), b2 = P(0, 1), c2 = P(0, 3), d2 = P(0, 2);
        auto bil2 = [&](float u, float v) { return lerp3(lerp3(a2, b2, u), lerp3(d2, c2, u), v); };
        V3 off2 = fwd * -0.015f;
        uint32_t tl = cv.brake ? rgb(255, 50, 40) : rgb(140, 14, 14);
        R.quad(bil2(0.05f, 0.5f) + off2, bil2(0.32f, 0.5f) + off2, bil2(0.32f, 0.85f) + off2, bil2(0.05f, 0.85f) + off2, tl, 1.0f, true, 0.0004f);
        R.quad(bil2(0.68f, 0.5f) + off2, bil2(0.95f, 0.5f) + off2, bil2(0.95f, 0.85f) + off2, bil2(0.68f, 0.85f) + off2, tl, 1.0f, true, 0.0004f);
        if (cv.reverse) {
            R.quad(bil2(0.36f, 0.5f) + off2, bil2(0.46f, 0.5f) + off2, bil2(0.46f, 0.7f) + off2, bil2(0.36f, 0.7f) + off2, rgb(250, 250, 250), 1.0f, true, 0.0004f);
            R.quad(bil2(0.54f, 0.5f) + off2, bil2(0.64f, 0.5f) + off2, bil2(0.64f, 0.7f) + off2, bil2(0.54f, 0.7f) + off2, rgb(250, 250, 250), 1.0f, true, 0.0004f);
        }
    }
    for (int i = 0; i < 4; i++) drawWheel(R, cv.p[24 + i], fwd, right, cv.wang[i], cv.steer, i < 2, (i & 1) == 0);
}

// Isinli kiris gorunumu (BeamNG tarzi): gerinim -> renk
inline void drawBeamsDebug(Renderer& R, const Car& car) {
    for (const Beam& b : car.b) {
        if (b.broken) continue;
        float l = len(car.n[b.b].p - car.n[b.a].p);
        float s = (l - b.rest0) / b.rest0;
        float t = clampf(fabsf(s) * 12.0f, 0, 1);
        uint32_t col = s >= 0 ? mixc(rgb(40, 200, 80), rgb(255, 60, 40), t) : mixc(rgb(40, 200, 80), rgb(60, 120, 255), t);
        if (b.type == 1) col = rgb(255, 220, 40);
        R.line3(car.n[b.a].p, car.n[b.b].p, col);
    }
}
