#pragma once
#include <ctype.h>
#include <string>
#include "car.h"
#include "input.h"
#include "netclient.h"
#include "proc.h"
#include "serverlib.h"
#include "render.h"
#include "scene.h"
#include "world.h"

struct Game {
    World world; Car car; NetClient net; Renderer R;
    enum Mode { MENU, CONNECTING, PLAY } mode = MENU;
    bool multi = false;
    char name[17] = "Oyuncu"; char addr[48] = "127.0.0.1:7777";
    int field = 0, colorIdx = 0;
    std::string menuMsg;
    double acc = 0, tNet = 0, clock = 0; float fps = 60;
    V3 camDir = V3(1, 0, 0), camPos; int camMode = 0;
    bool beams = false, help = true, quitReq = false;
    float steerS = 0, thrS = 0, brkS = 0, menuAng = 0;
    int respawnPulse = 0;
    std::vector<int> nearBoxes; std::vector<RPoint> rpts; std::vector<std::pair<int, int>> topo;
    CarView rviews[32]; bool rok[32] = {false};
    std::string toast; double toastT = 0;
    bool touch = false, wantKeyboard = false;   // Android/dokunmatik mod
    bool keysDown[K_COUNT] = {false};
    // --- sunucu barindirma (oyunun icinde) + playit.gg ---
    GameServer* srv = nullptr; ProcRunner playit;
    bool hosting = false, usePlayit = true, claimOpened = false, showPlayit = false, kbShift = false;
    int hostPort = 7777, playitAttempt = 0; double playitStart = 0;
    char pub[64] = "";
    std::string settingsPath;
    void loadSettings() {
        if (settingsPath.empty()) return;
        FILE* f = fopen(settingsPath.c_str(), "r"); if (!f) return;
        char n[64] = {0}, a[96] = {0}, pb[96] = {0}; int c = 0, up = 1;
        int got = fscanf(f, "%15s %47s %d %63s %d", n, a, &c, pb, &up);
        if (got >= 2) {
            strncpy(name, n, 15); name[15] = 0; strncpy(addr, a, 47); addr[47] = 0; colorIdx = c & 7;
            if (got >= 4 && strcmp(pb, "-") != 0) { strncpy(pub, pb, 63); pub[63] = 0; }
            if (got >= 5 && ProcRunner::supported()) usePlayit = up != 0;
        }
        fclose(f);
    }
    void saveSettings() {
        if (settingsPath.empty()) return;
        FILE* f = fopen(settingsPath.c_str(), "w"); if (!f) return;
        fprintf(f, "%s %s %d %s %d\n", name, addr, colorIdx, pub[0] ? pub : "-", usePlayit ? 1 : 0); fclose(f);
    }
    std::string playitExe, lanIp, claimUrl, detectedAddr, playitBuf;
    std::deque<std::string> playitLines;

    void init(int w, int h) {
        R.init(w, h); world.build(); topo = sampleTopology();
        playitExe = ProcRunner::findPlayit(); if (!ProcRunner::supported()) usePlayit = false;
        car.build(V3(0, 0, 0), 0);
        const char* e = getenv("USER"); if (!e) e = getenv("USERNAME");
        if (e && *e) { strncpy(name, e, 15); name[15] = 0; }
        for (int i = 0; i < 90; i++) { car.updateControls(0.016f); for (int s = 0; s < 16; s++) car.step(cfg::DT, nullptr, world, nullptr); }
    }
    void say(const std::string& s) { toast = s; toastT = 4.0; }

    // ---- baslatma ----
    void spawn(bool multiplayer) {
        multi = multiplayer;
        float x = 0, z = 0;
        if (multiplayer) { x = -20; z = -60 + net.myId * 5.0f; }
        car.build(V3(x, World::height(x, z) + 0.05f, z), 0);
        camDir = V3(1, 0, 0); acc = 0; steerS = thrS = brkS = 0; respawnPulse = 6;
        mode = PLAY;
    }
    void startSingle() { saveSettings(); net.close(); spawn(false); say("Tek oyunculu mod"); }
    void startConnect() {
        saveSettings();
        if (!net.begin(addr, name, (uint8_t)colorIdx)) { menuMsg = net.status; mode = MENU; return; }
        mode = CONNECTING; menuMsg.clear();
    }
    void leave() { net.close(); stopHost(); multi = false; mode = MENU; car.build(V3(0, World::height(0, 0), 0), 0); }

    // ---------- sunucu kur (gomulu) ----------
    std::string pubAddr() const { return pub[0] ? std::string(pub) : detectedAddr; }
    void stopHost() {
        playit.stop();
        if (srv) { srv->stop(); delete srv; srv = nullptr; }
        hosting = false;
    }
    void startHost() {
        if (!*name) strcpy(name, "Oyuncu");
        saveSettings();
        int port = 7777; const char* c = strrchr(addr, ':');
        if (c) { int p = atoi(c + 1); if (p > 1023 && p < 65536) port = p; }
        stopHost();
        srv = new GameServer(); std::string err; char sn[25]; snprintf(sn, sizeof(sn), "%.12s sunucusu", name);
        if (!srv->start(port, sn, 16, err)) { menuMsg = err; delete srv; srv = nullptr; return; }
        hosting = true; hostPort = port; lanIp = localIp();
        claimUrl.clear(); detectedAddr.clear(); playitLines.clear(); playitBuf.clear(); claimOpened = false;
        if (usePlayit && !playitExe.empty()) launchPlayit(0);
        char loc[48]; snprintf(loc, sizeof(loc), "127.0.0.1:%d", port);
        if (!net.begin(loc, name, (uint8_t)colorIdx)) { menuMsg = net.status; stopHost(); return; }
        mode = CONNECTING; menuMsg.clear();
    }
    void launchPlayit(int attempt) {
        playitAttempt = attempt; playitStart = nowSec();
        std::vector<std::string> args; if (attempt == 0) args.push_back("--stdout");
        if (!playit.start(playitExe, args)) { addPlayitLine("playit başlatılamadı: " + playitExe); return; }
        addPlayitLine(attempt == 0 ? "playit başlatıldı (--stdout)" : "playit başlatıldı (parametresiz)");
    }
    void addPlayitLine(const std::string& s) { playitLines.push_back(s); while (playitLines.size() > 40) playitLines.pop_front(); }
    static std::string stripAnsi(const std::string& s) {
        std::string o;
        for (size_t i = 0; i < s.size(); i++) {
            unsigned char c = (unsigned char)s[i];
            if (c == 0x1b) { i++; if (i < s.size() && s[i] == '[') { i++; while (i < s.size() && !((s[i] >= '@' && s[i] <= '~'))) i++; } continue; }
            if (c == '\r') o += '\n'; else if (c == '\n' || c >= 32) o += (char)c;
        }
        return o;
    }
    void scanPlayitLine(const std::string& line) {
        std::string tok; std::vector<std::string> toks;
        for (char c : line) { if (c == ' ' || c == '\t' || c == '"' || c == '\'' || c == ',' || c == '(' || c == ')' || c == '[' || c == ']' || c == '<' || c == '>') { if (!tok.empty()) toks.push_back(tok); tok.clear(); } else tok += c; }
        if (!tok.empty()) toks.push_back(tok);
        for (auto t : toks) {
            while (!t.empty() && (t.back() == '.' || t.back() == ';' || t.back() == ':')) t.pop_back();
            std::string lt = lowerStr(t);
            if (lt.find("playit.gg/claim") != std::string::npos && claimUrl.empty()) {
                claimUrl = lt.compare(0, 4, "http") == 0 ? t : "https://" + t;
            } else if ((lt.find("joinmc.link") != std::string::npos || lt.find("ply.gg") != std::string::npos || lt.find(".playit.gg") != std::string::npos) &&
                       lt.find("/claim") == std::string::npos) {
                size_t c = t.rfind(':');
                if (c != std::string::npos && c + 1 < t.size() && isdigit((unsigned char)t[c + 1])) { size_t e = c + 1; while (e < t.size() && isdigit((unsigned char)t[e])) e++; detectedAddr = t.substr(0, e); size_t sc = detectedAddr.find("://"); if (sc != std::string::npos) detectedAddr = detectedAddr.substr(sc + 3); }
            }
        }
    }
    void pumpPlayit() {
        if (!playit.started) return;
        std::string out = playit.readOutput();
        if (!out.empty()) {
            playitBuf += stripAnsi(out);
            size_t p;
            while ((p = playitBuf.find('\n')) != std::string::npos) {
                std::string line = playitBuf.substr(0, p); playitBuf.erase(0, p + 1);
                if (line.empty()) continue;
                addPlayitLine(line); scanPlayitLine(line);
            }
            if (playitBuf.size() > 2000) playitBuf.clear();
        }
        if (!claimUrl.empty() && !claimOpened) { claimOpened = true; openUrl(claimUrl); say("Playit onay sayfası tarayıcıda açıldı"); }
        if (!playit.alive()) {
            std::string rest = playit.readOutput(); if (!rest.empty()) for (auto& l : {stripAnsi(rest)}) { addPlayitLine(l); scanPlayitLine(l); }
            if (playitAttempt == 0 && nowSec() - playitStart < 6.0) { playit.stop(); launchPlayit(1); }
            else if (playit.started) { addPlayitLine("playit kapandı"); playit.stop(); }
        }
    }
    void respawn() {
        V3 c = car.center; float yaw = atan2f(car.fwd.z, car.fwd.x);
        if (!std::isfinite(yaw) || !finite3(c)) { c = V3(0, 0, 0); yaw = 0; }
        car.build(V3(c.x, World::height(c.x, c.z) + 0.5f, c.z), yaw);
        car.respawnCount++; respawnPulse = 6; steerS = 0;
    }

    // ---- menu ----
    void updateMenu(const Input& in) {
        char* f = field == 0 ? name : field == 1 ? addr : pub; size_t cap = field == 0 ? 15 : field == 1 ? 40 : 60;
        for (char c : in.text) { size_t l = strlen(f); if (l < cap) { f[l] = c; f[l + 1] = 0; } }
        if (in.pressed[K_BACK]) { size_t l = strlen(f); if (l) f[l - 1] = 0; }
        if (in.pressed[K_TAB] || in.pressed[K_DOWN]) field = (field + 1) % 3;
        if (in.pressed[K_UP]) field = (field + 2) % 3;
        if (in.pressed[K_LEFT]) colorIdx = (colorIdx + 7) & 7;
        if (in.pressed[K_RIGHT]) colorIdx = (colorIdx + 1) & 7;
        if (in.pressed[K_F3] && ProcRunner::supported()) usePlayit = !usePlayit;
        if (in.pressed[K_F1]) startSingle();
        else if (in.pressed[K_F2]) { wantKeyboard = false; startHost(); }
        else if (in.pressed[K_ENTER]) { if (!*name) strcpy(name, "Oyuncu"); wantKeyboard = false; startConnect(); }
        if (in.pressed[K_ESC]) { if (wantKeyboard) wantKeyboard = false; else quitReq = true; }
    }

    // ---- ana guncelleme ----
    void update(double dt, const Input& in) {
        if (dt > 0.1) dt = 0.1;
        memcpy(keysDown, in.down, sizeof(keysDown));
        clock += dt; fps += ((float)(1.0 / std::max(dt, 1e-4)) - fps) * 0.05f;
        if (toastT > 0) toastT -= dt;
        if (srv) srv->poll(nowSec());
        pumpPlayit();
        net.update(nowSec());
        if (mode == CONNECTING) {
            if (net.connected) { spawn(true); say("Sunucuya bağlanıldı: " + net.serverName); }
            else if (net.failed) { menuMsg = net.status; mode = MENU; stopHost(); }
            else if (in.pressed[K_ESC]) { net.close(); stopHost(); mode = MENU; menuMsg = "İptal edildi"; }
        } else if (mode == MENU) updateMenu(in);
        if (mode == PLAY && multi && (!net.connected)) { menuMsg = net.status.empty() ? "Bağlantı koptu" : net.status; leave(); }

        if (mode == PLAY) {
            if (in.pressed[K_ESC]) { leave(); return; }
            if (in.pressed[K_R]) respawn();
            if (in.pressed[K_C]) camMode = (camMode + 1) % 3;
            if (in.pressed[K_B]) beams = !beams;
            if (in.pressed[K_H]) help = !help;
            if (in.pressed[K_P]) showPlayit = !showPlayit;
            if (in.pressed[K_T]) { car.tcsOn = !car.tcsOn; say(car.tcsOn ? "Çekiş kontrolü: AÇIK" : "Çekiş kontrolü: KAPALI"); }
            float thr = (in.down[K_W] || in.down[K_UP]) ? 1.f : 0.f, brk = (in.down[K_S] || in.down[K_DOWN]) ? 1.f : 0.f;
            float st = ((in.down[K_D] || in.down[K_RIGHT]) ? 1.f : 0.f) - ((in.down[K_A] || in.down[K_LEFT]) ? 1.f : 0.f);
            thrS += clampf(thr - thrS, -6.0f * (float)dt, 4.5f * (float)dt);
            brkS += clampf(brk - brkS, -10.0f * (float)dt, 6.0f * (float)dt);
            float rate = (st != 0 && st * steerS >= 0) ? 3.2f / (1.0f + fabsf(car.speed) / 30.0f) : 6.0f;
            steerS += clampf(st - steerS, -rate * (float)dt, rate * (float)dt);
            car.inThrottle = thrS; car.inBrake = brkS; car.inHand = in.down[K_SPACE] ? 1.f : 0.f; car.steerIn = steerS;
        } else { car.inThrottle = car.inBrake = car.inHand = 0; car.steerIn = 0; }

        // yakindaki engeller
        nearBoxes.clear();
        for (size_t i = 0; i < world.boxes.size(); i++) {
            const Box& b = world.boxes[i];
            float r = fmaxf(b.h.x, b.h.z) * 1.5f + 16;
            if (fabsf(b.c.x - car.center.x) < r && fabsf(b.c.z - car.center.z) < r) nearBoxes.push_back((int)i);
        }
        // uzak araclar
        rpts.clear();
        double now = nowSec();
        for (int i = 0; i < 32; i++) rok[i] = false;
        if (mode == PLAY && multi) {
            for (int id = 1; id < 32; id++) {
                CarView& cv = rviews[id]; V3 vel[proto::NODES]; float st = 0; uint8_t fl = 0;
                if (!net.interp(id, now, cv.p, vel, cv.wang, st, fl)) continue;
                rok[id] = true; cv.steer = st; cv.color = PALETTE[net.remotes[id].color & 7]; cv.brake = fl & proto::F_BRAKE; cv.reverse = fl & proto::F_REVERSE;
                V3 cc = cv.p[ix(2, 0)];
                if (len(cc - car.center) < 12.0f)
                    for (auto& s : topo) {
                        RPoint q;
                        if (s.second < 0) { q.p = cv.p[s.first]; q.v = vel[s.first]; }
                        else { q.p = (cv.p[s.first] + cv.p[s.second]) * 0.5f; q.v = (vel[s.first] + vel[s.second]) * 0.5f; }
                        rpts.push_back(q);
                    }
            }
        }
        // fizik
        car.updateControls((float)dt);
        acc += dt;
        int steps = 0;
        while (acc >= cfg::DT && steps < 60) {
            car.step(cfg::DT, &nearBoxes, world, rpts.empty() ? nullptr : &rpts);
            for (auto& q : rpts) q.p += q.v * cfg::DT;
            acc -= cfg::DT; steps++;
        }
        if (acc > 0.05) acc = 0;
        for (auto& w : car.w) { w.angle = fmodf(w.angle, 2 * PI_F); }
        if (!car.healthy()) { car.build(V3(0, World::height(0, 0) + 0.3f, 0), 0); say("Fizik sıfırlandı"); }

        // ag
        if (mode == PLAY && multi && net.connected && now - tNet > 0.04) {
            tNet = now;
            proto::StateMsg m; car.toState(m);
            if (respawnPulse > 0) { m.flags |= proto::F_RESPAWN; respawnPulse--; }
            net.sendState(m);
        }
        updateCamera((float)dt);
    }

    V3 camTarget;
    float camFov = 70;
    void updateCamera(float dt) {
        if (mode != PLAY) {
            menuAng += dt * 0.35f;
            V3 c = car.center;
            camPos = c + V3(cosf(menuAng) * 7.5f, 1.9f, sinf(menuAng) * 7.5f);
            R.setCamera(camPos, c + V3(0, 0.5f, 0), V3(0, 1, 0), 60);
            return;
        }
        if (camMode == 1) {  // kaput ici
            V3 eye = (car.n[ix(2, 2)].p + car.n[ix(2, 3)].p) * 0.5f + car.up * -0.12f + car.fwd * 0.35f;
            R.setCameraBasis(eye, car.fwd - car.up * 0.04f, car.up, 80);
            camPos = eye; return;
        }
        V3 hv(car.vel.x, 0, car.vel.z), hf(car.fwd.x, 0, car.fwd.z);
        V3 desired = (len(hv) > 4.0f && car.speed > 0) ? norm(hv) : norm(hf);
        if (car.speed < -1.0f) desired = norm(hf);
        camDir = norm(lerp3(camDir, desired, clampf(dt * 3.5f, 0, 1)));
        camDir.y = 0; camDir = norm(camDir);
        float dist = (camMode == 2 ? 11.5f : 6.8f) + fabsf(car.speed) * 0.025f, h = camMode == 2 ? 4.2f : 2.3f;
        V3 target = car.center + V3(0, 0.75f, 0);
        V3 want = target - camDir * dist + V3(0, h, 0);
        float g = World::height(want.x, want.z) + 0.6f; if (want.y < g) want.y = g;
        camPos = lerp3(camPos, want, clampf(dt * 12.0f, 0, 1));
        if (len(camPos - want) > 6) camPos = want;
        R.setCamera(camPos, target + camDir * 2.5f, V3(0, 1, 0), 68 + clampf(fabsf(car.speed) * 0.25f, 0, 14));
    }

    // ---- cizim ----
    CarView localView() {
        CarView cv;
        for (int i = 0; i < proto::NODES; i++) cv.p[i] = car.n[i].p;
        for (int i = 0; i < 4; i++) cv.wang[i] = car.w[i].angle;
        cv.steer = car.steerAngle; cv.color = PALETTE[colorIdx & 7]; cv.brake = car.brake > 0.2f; cv.reverse = car.gear == -1;
        return cv;
    }

    void render() {
        R.clearSky();
        drawTerrain(R, R.cp);
        drawBoxes(R, world);
        CarView lv = localView();
        drawCarShadow(R, lv); drawCar(R, lv);
        if (mode == PLAY && multi)
            for (int id = 1; id < 32; id++) if (rok[id]) {
                drawCarShadow(R, rviews[id]); drawCar(R, rviews[id]);
            }
        if (beams && mode == PLAY) drawBeamsDebug(R, car);
        if (mode == PLAY && multi)
            for (int id = 1; id < 32; id++) if (rok[id]) {
                V3 c = (rviews[id].p[ix(2, 2)] + rviews[id].p[ix(3, 3)]) * 0.5f + V3(0, 0.9f, 0);
                float sx, sy, z; if (!R.project(c, sx, sy, z) || z > 260) continue;
                const char* nm = net.remotes[id].name[0] ? net.remotes[id].name : "?";
                R.textCentered((int)sx, (int)sy - 20, nm, rgb(255, 255, 255), 1);
                char b[24]; snprintf(b, sizeof(b), "%.0f m", len(c - car.center)); R.textCentered((int)sx, (int)sy - 4, b, rgb(200, 220, 255), 1, 0.8f);
            }
        if (mode == PLAY) drawHUD(); else drawMenu();
    }

    struct R4 { int x, y, w, h; };
    struct MenuLay { R4 field[3], btn[3], cL, cR, sw, panel; int titleY, titleScale, subY, T; bool kb; };
    bool kbVisible() const { return touch && wantKeyboard && mode == MENU; }
    MenuLay menuLay() const {
        MenuLay l; memset(&l, 0, sizeof(l)); int W = R.W, H = R.H; l.kb = kbVisible();
        if (l.kb) { for (int i = 0; i < 3; i++) l.field[i] = {20, 8 + i * 42, W - 40, 36}; return l; }
        int oy = H >= 600 ? 40 : 0;
        l.titleScale = 4; l.titleY = oy + 8; l.subY = oy + 80; l.T = oy + 104;
        int pw = std::min(900, W - 20), px = (W - pw) / 2, T = l.T, lx = px + 20, lw = std::min(410, pw / 2 - 30);
        l.panel = {px, T - 8, pw, 292};
        for (int i = 0; i < 3; i++) l.field[i] = {lx, T + 30 + i * 62, lw, 32};
        l.cL = {lx + 110, T + 200, 44, 40}; l.sw = {lx + 160, T + 204, 50, 32}; l.cR = {lx + 216, T + 200, 44, 40};
        int bx = px + pw / 2 + 10, bw = pw / 2 - 30;
        for (int i = 0; i < 3; i++) l.btn[i] = {bx, T + 8 + i * 68, bw, 58};
        return l;
    }

    // ---- oyun ici ekran klavyesi (sistem klavyesi Android'de guvenilir degil) ----
    struct KbKey { int x, y, w, h; char ch; int kind; std::string label; };
    std::vector<KbKey> kbKeys() const {
        std::vector<KbKey> v; int W = R.W, H = R.H, rows = 5;
        int rh = std::min(54, (H - 140) / rows), top = H - rows * rh - 4; float unit = (W - 16) / 10.0f;
        auto add = [&](float u0, float u1, int row, char ch, int kind, const std::string& label) {
            v.push_back({(int)(8 + u0 * unit) + 2, top + row * rh + 2, (int)((u1 - u0) * unit) - 4, rh - 4, ch, kind, label});
        };
        const char* r0 = "1234567890"; const char* r1 = "qwertyuiop"; const char* r2 = "asdfghjkl"; const char* r3 = "zxcvbnm"; const char* r4 = ".:-_/";
        for (int i = 0; i < 10; i++) add((float)i, i + 1.0f, 0, r0[i], 0, std::string(1, r0[i]));
        for (int i = 0; i < 10; i++) add((float)i, i + 1.0f, 1, r1[i], 0, std::string(1, kbShift ? (char)toupper(r1[i]) : r1[i]));
        for (int i = 0; i < 9; i++) add(0.5f + i, 1.5f + i, 2, r2[i], 0, std::string(1, kbShift ? (char)toupper(r2[i]) : r2[i]));
        add(0, 1.5f, 3, 0, 1, "Aa");
        for (int i = 0; i < 7; i++) add(1.5f + i, 2.5f + i, 3, r3[i], 0, std::string(1, kbShift ? (char)toupper(r3[i]) : r3[i]));
        add(8.5f, 10, 3, 0, 2, "SİL");
        for (int i = 0; i < 5; i++) add((float)i, i + 1.0f, 4, r4[i], 0, std::string(1, r4[i]));
        add(5, 10, 4, 0, 3, "TAMAM");
        return v;
    }

    void menuTap(int x, int y, Input& in) {
        auto hit = [&](const R4& r) { return x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h; };
        if (mode == CONNECTING) { in.pressed[K_ESC] = true; return; }
        if (mode != MENU) return;
        MenuLay l = menuLay();
        if (l.kb) {
            for (int i = 0; i < 3; i++) if (hit(l.field[i])) { field = i; return; }
            for (auto& k : kbKeys()) if (hit({k.x, k.y, k.w, k.h})) {
                if (k.kind == 0) { in.text.push_back(kbShift ? (char)toupper(k.ch) : k.ch); kbShift = false; }
                else if (k.kind == 1) kbShift = !kbShift;
                else if (k.kind == 2) in.pressed[K_BACK] = true;
                else wantKeyboard = false;
                return;
            }
            return;
        }
        for (int i = 0; i < 3; i++) if (hit(l.field[i])) { field = i; wantKeyboard = true; return; }
        if (hit(l.cL)) in.pressed[K_LEFT] = true;
        else if (hit(l.cR)) in.pressed[K_RIGHT] = true;
        else if (hit(l.btn[0])) in.pressed[K_F1] = true;
        else if (hit(l.btn[1])) in.pressed[K_ENTER] = true;
        else if (hit(l.btn[2])) in.pressed[K_F2] = true;
    }

    struct TBtn { int x, y, w, h, key; const char* label; int scale; };
    std::vector<TBtn> touchButtons() const {
        int W = R.W, H = R.H;
        return {{24, H - 150, 120, 130, K_A, "<", 5}, {156, H - 150, 120, 130, K_D, ">", 5},
                {W - 170, H - 230, 150, 210, K_W, "GAZ", 3}, {W - 330, H - 170, 145, 150, K_S, "FREN", 2},
                {W - 330, H - 246, 145, 66, K_SPACE, "EL FRENİ", 1},
                {W - 300, 10, 90, 44, K_ESC, "MENÜ", 1}, {W - 200, 10, 90, 44, K_R, "SIFIRLA", 1}, {W - 100, 10, 90, 44, K_C, "KAMERA", 1}};
    }
    void drawTouchUI() {
        for (auto& b : touchButtons()) {
            bool on = keysDown[b.key];
            R.rect(b.x, b.y, b.w, b.h, on ? rgb(255, 255, 255) : rgb(200, 215, 240), on ? 0.40f : 0.20f);
            R.frame(b.x, b.y, b.w, b.h, rgb(255, 255, 255), 0.7f);
            R.textCentered(b.x + b.w / 2, b.y + b.h / 2 - FONT_CH * b.scale / 2, b.label, rgb(255, 255, 255), b.scale, 0.9f);
        }
    }

    void drawField(const R4& r, const char* label, const char* val, bool act, bool inside) {
        if (!inside) R.text(r.x, r.y - 20, label, rgb(170, 190, 220), 1);
        R.rect(r.x, r.y, r.w, r.h, rgb(30, 40, 60), 0.92f);
        R.frame(r.x, r.y, r.w, r.h, act ? rgb(255, 210, 70) : rgb(90, 110, 150), 1);
        std::string s = val; if (act && ((int)(clock * 2) & 1)) s += "_";
        if (inside) { R.text(r.x + 8, r.y + (r.h - FONT_CH) / 2, label, rgb(170, 190, 220), 1); R.text(r.x + 230, r.y + (r.h - FONT_CH) / 2, s.c_str(), rgb(255, 255, 255), 1); }
        else R.text(r.x + 8, r.y + (r.h - FONT_CH) / 2, s.c_str(), rgb(255, 255, 255), 1);
    }
    void drawButton(const R4& r, const char* label, uint32_t col) {
        R.rect(r.x, r.y, r.w, r.h, col, 0.30f); R.frame(r.x, r.y, r.w, r.h, col, 0.95f);
        R.textCentered(r.x + r.w / 2, r.y + (r.h - FONT_CH * 2) / 2, label, rgb(255, 255, 255), 2);
    }

    void drawMenu() {
        int W = R.W, H = R.H; MenuLay l = menuLay();
        if (l.kb) {
            R.rect(0, 0, W, H, rgb(0, 0, 0), 0.6f);
            drawField(l.field[0], "Oyuncu adı", name, field == 0, true);
            drawField(l.field[1], "Sunucu ip:port", addr, field == 1, true);
            drawField(l.field[2], "Genel adres", pub, field == 2, true);
            for (auto& k : kbKeys()) {
                bool special = k.kind != 0;
                R.rect(k.x, k.y, k.w, k.h, special ? rgb(70, 90, 140) : rgb(45, 55, 80), 0.95f);
                R.frame(k.x, k.y, k.w, k.h, rgb(140, 160, 210), 0.9f);
                uint32_t c = (k.kind == 1 && kbShift) ? rgb(255, 210, 70) : (k.kind == 3 ? rgb(130, 255, 160) : rgb(255, 255, 255));
                if (k.kind == 0 && k.ch == '_') R.rect(k.x + k.w / 2 - 12, k.y + k.h / 2 + 6, 24, 4, c);   // font hucresine sigmayan alt cizgi
                else R.textCentered(k.x + k.w / 2, k.y + (k.h - FONT_CH * 2) / 2, k.label.c_str(), c, 2, 1.0f);
            }
            return;
        }
        R.rect(0, 0, W, H, rgb(0, 0, 0), 0.25f);
        R.textCentered(W / 2, l.titleY, "BEAMX", rgb(255, 210, 70), l.titleScale);
        R.textCentered(W / 2, l.subY, "Yumuşak gövde araç simülatörü  -  PC & Android  -  Çok oyunculu", rgb(230, 235, 245), 1);
        R.rect(l.panel.x, l.panel.y, l.panel.w, l.panel.h, rgb(10, 14, 22), 0.74f);
        R.frame(l.panel.x, l.panel.y, l.panel.w, l.panel.h, rgb(120, 160, 220), 0.8f);
        drawField(l.field[0], "Oyuncu adı", name, field == 0, false);
        drawField(l.field[1], "Katılmak için sunucu (ip:port)", addr, field == 1, false);
        drawField(l.field[2], "Genel adres (playit, isteğe bağlı)", pub, field == 2, false);
        int lx = l.field[0].x, ry = l.T + 212;
        R.text(lx, ry, "Araç rengi", rgb(170, 190, 220), 1);
        R.text(l.cL.x + 16, ry, "<", rgb(255, 255, 255), 1);
        R.rect(l.sw.x, l.sw.y, l.sw.w, l.sw.h, PALETTE[colorIdx & 7]); R.frame(l.sw.x, l.sw.y, l.sw.w, l.sw.h, rgb(255, 255, 255), 0.8f);
        R.text(l.cR.x + 16, ry, ">", rgb(255, 255, 255), 1);
        R.text(l.cR.x + 50, ry, PALETTE_NAME[colorIdx & 7], rgb(230, 235, 245), 1);
        int bx = l.btn[0].x, bw = l.btn[0].w;
        if (mode == CONNECTING) {
            R.textCentered(bx + bw / 2, l.btn[0].y + 20, net.status.c_str(), rgb(255, 230, 120), 2);
            if (hosting) R.textCentered(bx + bw / 2, l.btn[0].y + 62, "Sunucu başlatılıyor...", rgb(190, 220, 255), 1);
            R.textCentered(bx + bw / 2, l.btn[0].y + 100, touch ? "(iptal için dokun)" : "[Esc] İptal", rgb(190, 200, 220), 1);
        } else {
            drawButton(l.btn[0], "Tek oyunculu", rgb(60, 200, 110));
            drawButton(l.btn[1], "Sunucuya bağlan", rgb(70, 150, 240));
            drawButton(l.btn[2], "Sunucu kur ve oyna", rgb(240, 160, 50));
            int ty2 = l.T + 216;
            if (ProcRunner::supported()) {
                std::string a = std::string("[F3] playit.gg ile internete aç: ") + (usePlayit ? "AÇIK" : "KAPALI");
                R.text(bx, ty2, a.c_str(), usePlayit ? rgb(130, 230, 150) : rgb(255, 170, 90), 1);
                std::string st = playitExe.empty() ? "playit bulunamadı: oyun klasörüne koyun" : "playit: " + playitExe.substr(playitExe.find_last_of("/\\") == std::string::npos ? 0 : playitExe.find_last_of("/\\") + 1);
                R.text(bx, ty2 + 20, st.c_str(), playitExe.empty() ? rgb(255, 150, 120) : rgb(190, 215, 255), 1, 0.9f);
            } else R.text(bx, ty2, "Telefonda sunucu: aynı Wi-Fi / hotspot", rgb(190, 215, 255), 1);
            if (!touch) R.text(l.field[0].x, l.panel.y + l.panel.h - 22, "F1 tek  |  Enter bağlan  |  F2 sunucu kur  |  Tab alan  |  < > renk  |  Esc çıkış", rgb(160, 175, 200), 1, 0.9f);
        }
        if (!menuMsg.empty()) R.textCentered(W / 2, l.panel.y + l.panel.h + 12, menuMsg.c_str(), rgb(255, 110, 100), 2);
    }

    void drawHUD() {
        int W = R.W, H = R.H;
        // --- gosterge ---
        int gx = W - 150, gy = H - 150, gr = 120;
        if (touch) { gx = W / 2; gy = 86; gr = 72; }
        float kk = gr / 120.0f;
        R.blendDisc(gx, gy, gr + 6, rgb(0, 0, 0), 0.5f);
        float a0 = 135 * PI_F / 180, sweep = 270 * PI_F / 180;
        R.arc(gx, gy, (float)gr, a0, a0 + sweep, rgb(200, 210, 230), 0.7f, 1);
        R.arc(gx, gy, gr - 3.0f, a0 + sweep * 0.85f, a0 + sweep, rgb(255, 60, 50), 1, 4);
        for (int i = 0; i <= 8; i++) {
            float a = a0 + sweep * i / 8.0f;
            R.line2(gx + (int)(cosf(a) * gr * 0.86f), gy + (int)(sinf(a) * gr * 0.86f), gx + (int)(cosf(a) * gr * 0.98f), gy + (int)(sinf(a) * gr * 0.98f), rgb(230, 235, 245));
            char b[4]; snprintf(b, sizeof(b), "%d", i);
            R.text(gx + (int)(cosf(a) * gr * 0.70f) - 4, gy + (int)(sinf(a) * gr * 0.70f) - 8, b, rgb(210, 220, 240), 1, 0.9f, false);
        }
        float na = a0 + sweep * clampf(car.rpm / 8000.0f, 0, 1);
        for (int o = -1; o <= 1; o++) R.line2(gx + o, gy, gx + (int)(cosf(na) * gr * 0.85f) + o, gy + (int)(sinf(na) * gr * 0.85f), rgb(255, 150, 40));
        R.blendDisc(gx, gy, 6, rgb(255, 150, 40), 1);
        char sp[16]; snprintf(sp, sizeof(sp), "%d", (int)(fabsf(car.speed) * 3.6f + 0.5f));
        R.textCentered(gx, gy - (int)(52 * kk), sp, rgb(255, 255, 255), touch ? 3 : 4);
        R.textCentered(gx, gy + (int)(24 * kk), "km/h", rgb(190, 200, 220), 1);
        const char* gs[8]; char gb[4]; snprintf(gb, sizeof(gb), "%d", car.gear);
        (void)gs;
        const char* gtxt = car.gear == -1 ? "R" : car.gear == 0 ? "N" : gb;
        R.textCentered(gx, gy + (int)(46 * kk), gtxt, car.gear == -1 ? rgb(255, 120, 100) : rgb(120, 255, 150), touch ? 2 : 3);
        // --- hasar / durum ---
        int bx = 24, by = H - 110;
        if (touch) { bx = W - 250; by = 84; }
        R.rect(bx - 8, by - 12, 270, touch ? 60 : 100, rgb(0, 0, 0), 0.45f);
        float dm = clampf(car.damage() * 2.0f, 0, 100);
        R.text(bx, by - 6, "HASAR", rgb(230, 235, 245), 1);
        R.rect(bx, by + 14, 240, 14, rgb(40, 40, 46), 0.9f);
        R.rect(bx, by + 14, (int)(240 * dm / 100.0f), 14, mixc(rgb(60, 220, 90), rgb(255, 50, 40), dm / 100.0f));
        R.frame(bx, by + 14, 240, 14, rgb(200, 205, 220), 0.7f);
        char b[64]; snprintf(b, sizeof(b), "%%%d   kopan kiriş: %d", (int)dm, car.brokenCount);
        R.text(bx, by + 32, b, rgb(230, 235, 245), 1);
        if (!touch) R.text(bx, by + 54, car.tcsOn ? "Çekiş kontrolü: AÇIK" : "Çekiş kontrolü: KAPALI", car.tcsOn ? rgb(130, 230, 150) : rgb(255, 170, 90), 1);
        // --- ust sol ---
        int ty = 10;
        snprintf(b, sizeof(b), "FPS %d", (int)(fps + 0.5f)); R.text(12, ty, b, rgb(255, 255, 255), 1); ty += 20;
        if (multi) {
            snprintf(b, sizeof(b), "%s  |  Ping %d ms  |  Oyuncu %d", net.serverName.c_str(), net.pingMs, net.activeCount() + 1);
            R.text(12, ty, b, rgb(150, 220, 255), 1); ty += 22;
            R.rect(12, ty + 2, 12, 12, PALETTE[colorIdx & 7]); R.text(30, ty, (std::string(name) + " (sen)").c_str(), rgb(255, 255, 255), 1); ty += 20;
            for (int id = 1; id < 32; id++) if (net.remotes[id].active) {
                R.rect(12, ty + 2, 12, 12, PALETTE[net.remotes[id].color & 7]);
                snprintf(b, sizeof(b), "%s", net.remotes[id].name); R.text(30, ty, b, rgb(230, 235, 245), 1); ty += 20;
            }
        } else R.text(12, ty, "Tek oyunculu", rgb(150, 220, 255), 1);
        if (hosting && srv) {
            ty += 6;
            int lines = 3 + (!claimUrl.empty() && !touch ? 1 : 0) + (showPlayit && !touch ? (int)std::min<size_t>(6, playitLines.size()) + 1 : 0);
            R.rect(8, ty - 4, 600, lines * 20 + 8, rgb(0, 0, 0), 0.5f);
            snprintf(b, sizeof(b), "SUNUCU AÇIK  (UDP %d)  oyuncu %d/%d", hostPort, srv->count(), srv->maxPlayers); R.text(14, ty, b, rgb(255, 210, 90), 1); ty += 20;
            snprintf(b, sizeof(b), "Yerel ağ:  %s:%d", lanIp.c_str(), hostPort); R.text(14, ty, b, rgb(190, 230, 255), 1); ty += 20;
            std::string pa = pubAddr();
            if (!pa.empty()) { R.text(14, ty, ("İnternet:  " + pa).c_str(), rgb(130, 255, 160), 1); }
            else R.text(14, ty, playit.started ? "İnternet:  playit adresi bekleniyor..." : "İnternet:  (kapalı)", rgb(255, 200, 120), 1);
            ty += 20;
            if (!claimUrl.empty() && !touch) { R.text(14, ty, ("Playit onayı: " + claimUrl).c_str(), rgb(255, 230, 120), 1); ty += 20; }
            if (showPlayit && !touch) {
                R.text(14, ty, "[P] playit çıktısı:", rgb(160, 175, 200), 1); ty += 20;
                size_t from = playitLines.size() > 6 ? playitLines.size() - 6 : 0;
                for (size_t i = from; i < playitLines.size(); i++) { std::string s = playitLines[i]; if (s.size() > 64) s = s.substr(0, 64); R.text(14, ty, s.c_str(), rgb(210, 220, 235), 1, 0.9f); ty += 20; }
            }
        }
        if (toastT > 0) R.textCentered(W / 2, 70, toast.c_str(), rgb(255, 235, 140), 2, clampf((float)toastT, 0, 1));
        if (touch) drawTouchUI();
        if (help && !touch) R.textCentered(W / 2, H - 28, "W/S gaz-fren  A/D direksiyon  Boşluk el freni  R sıfırla  C kamera  B kiriş  T çekiş kontrolü  P playit  H gizle  Esc menü", rgb(235, 240, 250), 1, 0.85f);
    }
};
