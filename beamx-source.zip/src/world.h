#pragma once
#include <vector>
#include "vec.h"

// Statik engel (yaw ekseninde donmus kutu)
struct Box {
    V3 c, h;      // merkez, yari boyutlar
    float yaw, cs, sn;
    uint32_t col;
    void set(V3 C, V3 H, float Y, uint32_t Col) { c = C; h = H; yaw = Y; cs = cosf(Y); sn = sinf(Y); col = Col; }
    // dunya -> yerel (sadece x,z doner)
    V3 toLocal(const V3& p) const { V3 d = p - c; return V3(d.x * cs + d.z * sn, d.y, -d.x * sn + d.z * cs); }
    V3 toWorldDir(const V3& l) const { return V3(l.x * cs - l.z * sn, l.y, l.x * sn + l.z * cs); }
};

struct World {
    std::vector<Box> boxes;

    // Arazi yuksekligi: ortada duz test alani, disarida tepeler, rampa, titreme seridi, tümsek
    static float height(float x, float z) {
        float d = fmaxf(fabsf(x), fabsf(z));
        float hills = smoothstepf(220, 520, d) *
                      (18 * sinf(x * 0.011f + 1.3f) * cosf(z * 0.013f) + 9 * sinf(x * 0.027f + z * 0.021f) +
                       3 * sinf(x * 0.07f) * sinf(z * 0.06f));
        float h = hills;
        // atlama rampasi: x 70..95, |z|<6
        if (x > 70 && x < 95) {
            float e = 1.0f - smoothstepf(5.0f, 6.0f, fabsf(z));
            h += 3.4f * ((x - 70) / 25.0f) * e;
        }
        // titreme (washboard)
        if (x < -70 && x > -140) {
            float e = 1.0f - smoothstepf(7, 8, fabsf(z));
            h += 0.11f * sinf(x * 2.2f) * e;
        }
        // yuvarlak tumsek
        {
            float dx = x - 0, dz = z - 150;
            h += 3.5f * expf(-(dx * dx + dz * dz) / (2 * 14.0f * 14.0f));
        }
        // egimli yokus (rampa degil, uzun tirmanis)
        {
            float dx = x + 120, dz = z - 100;
            h += 9.0f * expf(-(dx * dx + dz * dz) / (2 * 28.0f * 28.0f));
        }
        return h;
    }
    static V3 normal(float x, float z) {
        const float e = 0.25f;
        float hx = height(x + e, z) - height(x - e, z);
        float hz = height(x, z + e) - height(x, z - e);
        return norm(V3(-hx / (2 * e), 1.0f, -hz / (2 * e)));
    }
    static float grip(float x, float z) {
        float d = fmaxf(fabsf(x), fabsf(z));
        return d < 260 ? 1.2f : 0.74f;
    }

    void build() {
        boxes.clear();
        auto add = [&](float x, float z, V3 h, float yaw, uint32_t col, float lift = 0) {
            Box b;
            b.set(V3(x, height(x, z) + h.y + lift, z), h, yaw, col);
            boxes.push_back(b);
        };
        const uint32_t CONC = 0xB4B4B0, ORANGE = 0xE8741A, CRATE = 0x9A6B3C, RED = 0xC03030;
        // carpisma duvari (ramp sonrasi)
        add(135, 0, V3(0.8f, 1.1f, 14), 0, CONC);
        // yan beton bariyerler
        for (int i = 0; i < 8; i++) add(-20 + i * 6.0f, 45, V3(1.5f, 0.45f, 0.35f), 0, CONC);
        // slalom konileri
        for (int i = 0; i < 10; i++) add(10 + i * 9.0f, (i % 2 ? 1 : -1) * 4.0f - 32, V3(0.18f, 0.4f, 0.18f), 0, ORANGE);
        // kirilabilir kasa yigini (sabit)
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 3; j++) add(-35 + i * 1.25f, -20 + j * 1.25f, V3(0.6f, 0.6f, 0.6f), 0.0f, CRATE);
        add(-35 + 0.6f, -20 + 0.6f, V3(0.6f, 0.6f, 0.6f), 0.2f, CRATE, 1.2f);
        // egik duvar (carpma acisi testi)
        add(-60, 40, V3(0.5f, 1.0f, 10), 0.6f, RED);
        // dis alanda rastgele kayalar/kasalar
        uint32_t s = 12345;
        auto rnd = [&]() { s = s * 1664525u + 1013904223u; return (s >> 8) / 16777216.0f; };
        for (int i = 0; i < 70; i++) {
            float x = (rnd() - 0.5f) * 900, z = (rnd() - 0.5f) * 900;
            if (fmaxf(fabsf(x), fabsf(z)) < 230) continue;
            float sz = 0.8f + rnd() * 2.2f;
            add(x, z, V3(sz, sz * 0.8f, sz), rnd() * 6.28f, 0x7A7468);
        }
    }
};
