#!/bin/sh
# Linux uzerinden Windows .exe derlemek icin (MinGW-w64 gerekir):
#   Debian/Ubuntu:  sudo apt install g++-mingw-w64-x86-64-posix
set -e
CXX=${CXX:-x86_64-w64-mingw32-g++-posix}
command -v $CXX >/dev/null 2>&1 || CXX=x86_64-w64-mingw32-g++
FLAGS="-O2 -std=c++17 -Wall -static -static-libgcc -static-libstdc++"
mkdir -p dist-windows
$CXX $FLAGS -mwindows -o dist-windows/beamx.exe src/main.cpp -lws2_32 -lgdi32 -luser32 -lwinmm -lshell32
$CXX $FLAGS -o dist-windows/beamx-server.exe src/server.cpp -lws2_32
echo "Hazir: dist-windows/beamx.exe  dist-windows/beamx-server.exe"
