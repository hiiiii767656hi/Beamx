# BeamX — yumuşak gövde (soft-body) araç simülatörü

BeamNG'den esinlenen, **düğüm-kiriş (node-beam)** fiziğiyle çalışan, çok oyunculu araç oyunu.
Harici kütüphane yok: kendi fizik motoru, kendi yazılım rasterizer'ı, UDP ağ kodu.

| Parça | Dosya | Platform |
|---|---|---|
| Oyun istemcisi | `beamx` / `beamx.exe` | Linux (X11) ve Windows |
| Android istemcisi | `android/` → APK | Android 5.0+ (arm64, arm32, x86_64) |
| Ayrı sunucu uygulaması | `beamx-server` | Linux (başsız, bağımlılıksız statik), Windows'ta da derlenir |

## Oynanış
- **W/S** gaz–fren (dururken S = geri vites), **A/D** direksiyon, **Boşluk** el freni
- **R** aracı sıfırla, **C** kamera (arka / kaput / uzak), **B** kiriş (gerinim) görünümü, **T** çekiş kontrolü aç/kapa, **H** yardım, **Esc** menü
- Menüde: ad ve sunucu IP'sini yazın, **Enter** = sunucuya bağlan, **F1** = tek oyunculu, **< >** = renk
- Komut satırı: `beamx --connect IP:7777 --name Ali --color 3 --res 1920x1080`

Test alanı: düz asfalt zemin, atlama rampası (ileri doğru), titreme (washboard) şeridi, tümsek ve yokuş, beton duvar,
slalom konileri, kasa yığını, dışarıda tepeler ve kayalar.

## Android (APK)
`android/` klasörü eksiksiz bir Gradle + NDK projesidir (NativeActivity, Java kodu yok). Aynı oyun kodunu kullanır.
- Dokunmatik kontroller: sol altta **< >** direksiyon, sağ altta **GAZ / FREN / EL FRENİ**, üstte MENÜ / SIFIRLA / KAMERA. Çoklu dokunma desteklenir.
- Menüde ad ve sunucu IP'si alanlarına dokununca ekran klavyesi açılır; ayarlar telefonda saklanır.
- **APK üretmek (en kolayı):** projeyi GitHub'a yükleyin → *Actions → android-apk* iş akışı ~5 dk içinde `BeamX-apk` çıktısını verir
  (içinde `app-release.apk`). Telefonda "bilinmeyen kaynaklardan kurulum"a izin verip kurun.
- **Kendi bilgisayarınızda:** Android Studio ile `android/` klasörünü açıp *Build → Build APK*, ya da
  JDK 17 + Android SDK/NDK 26 kuruluyken `gradle -p android assembleRelease`.
- Telefon sunucuya erişebilmeli: sunucu aynı Wi-Fi'de LAN IP'siyle ya da internet üzerinde UDP 7777 açık bir adresle.

## Sunucu kur (oyunun içinde) + playit.gg
Menüde **Sunucu kur ve oyna**: sunucu oyunun içinde açılır (Linux/ayrı program gerekmez; PC ve Android).
Internete açmak için **playit.gg** desteği var: ajanı oyun klasörüne koyun, oyun otomatik başlatır ve adresi gösterir.
Ayrıntılı adımlar: **PLAYIT_REHBERI.md**.
Android'de yazı girişi için sistem klavyesi yerine **oyunun kendi ekran klavyesi** kullanılır.

## Ayrı sunucu (başsız, isteğe bağlı)
```
./beamx-server --port 7777 --name "Benim Sunucum" --max 16
```
UDP 7777 portunu açın. Docker: `docker build -t beamx-server -f deploy/Dockerfile . && docker run -d -p 7777:7777/udp beamx-server`.
systemd örneği: `deploy/beamx-server.service`.

## Derleme
**Linux:** `sudo apt install g++ libx11-dev` → `make` (çıktı: `beamx`, `beamx-server`, `beamx-selftest`)
**Windows (Linux'tan çapraz):** `sudo apt install g++-mingw-w64-x86-64-posix` → `./build_windows.sh`
**Windows (doğrudan):** MSYS2/MinGW-w64 kurup `build_windows.bat`
**Otomatik:** `.github/workflows/build.yml` GitHub'a yüklenince hem Linux hem Windows ikililerini üretir.

## Mimari
- **Fizik (`car.h`)**: 28 düğüm, 144 kiriş, 1000 Hz sabit adım. Plastik deformasyon (kirişin boyu kalıcı değişir → göçük),
  kirişin kopması, kopan salıncak kolunda tekerleğin düşmesi. Süspansiyon: salıncak kolu + amortisör (viraj/sıkışma sınırlı).
  Lastik: yük bağımlı, birleşik kayma eğrisi, yuvarlanma direnci. Motor tork eğrisi, 6 ileri + geri otomatik vites,
  debriyaj, motor freni, açık diferansiyel, çekiş kontrolü, ABS'siz fren, aerodinamik sürtünme.
- **Çarpışma**: gövde kiriş orta noktaları dahil 124 örnek nokta ↔ arazi, kutular ve diğer oyuncuların araçları.
- **Ağ (`proto.h`, UDP)**: her istemci kendi aracının fiziğini yerelde çalıştırır (BeamNG/BeamMP modeli).
  Saniyede 25 kez tüm 28 düğümün konumu (mm hassasiyetinde, ~230 bayt) sunucuya gider, sunucu diğerlerine yayar.
  Uzak araçlar 100 ms gecikmeyle enterpole edilir; böylece göçükler de diğer oyuncularda görünür.
  Sunucu: katılım/ayrılma, benzersiz isim, ping, zaman aşımı, paket hız sınırı, geçersiz veri ve ışınlanma/hız hilesi kontrolü.
- **Grafik**: tamamen CPU'da 3B rasterizer (z-buffer, sis, saydamlık). 720p'de ~6 ms/kare.

## Sınırlar (dürüst liste)
- Ses yok. Tek araç modeli (sedan). Araç editörü / mod sistemi yok. Harita sabit (kod ile üretilen).
- Sunucu "istemci-yetkili": hileye karşı yalnızca makul-lik denetimi var, tam sunucu-yetkili fizik değil.
- Fizik BeamNG kadar ince değil (28 düğüm); kiriş sayısı arttırılarak detay artırılabilir (`Car::build`).
